local menuids = {}

menuids.QUIT = -2
menuids.GAME = -1
menuids.MAIN = 0
menuids.CREDITS = 1
menuids.HISCORE = 2
menuids.PAUSED = 3
menuids.GAMEOVER = 4
menuids.INTRO = 5
menuids.SELECT_WAVE = 6
menuids.BOSS_FIGHT_INTRO = 7
menuids.VICTORY = 8

return menuids
