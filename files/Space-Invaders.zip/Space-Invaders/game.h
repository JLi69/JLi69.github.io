#include "sprites.h"
#include <windows.h>
#include <vector>
#include <time.h>
#include <stdlib.h>
#include <math.h>
#include <sstream>
#include <fstream>
#include <string>
#pragma once

class Game {
private:
	//Gameobjects
	Player player = Player(100.0f, 590.0f);
	//Aliens
	std::vector<Alien> aliens;
	int timeUntilNextAlienShot = 70;
	std::vector<AlienBullet> alienbullets;
	//Bullets
	std::vector<Bullet> bullets;
	//Wall
	std::vector<WallPixel> wallpixels;
	//UFO
	UFO ufo = UFO(-400.0f, 44.0f);

	//Keep track of the score
	int score = 0;
	//Spawn alien wave
	void spawnWave() {
		for (float i = 0; i < 5; i++) {
			for (float j = 0; j < 10; j++) {
				int value = i;
				if (i == 2) {
					value = 1;
				}
				else if (i > 2) {
					value = 2;
				}
				Alien tempAlien = Alien(j * 56 + 50, i * 64 + 48 + 40, value);
				aliens.push_back(tempAlien);
			}
		}
		player.lives++;
	}

	//Get high score
	int getHighScore() {
		int highscore = 0;
		std::string line;
		std::ifstream file;

		file.open("highscore.txt");

		if (file.is_open()) {
			while (std::getline(file, line)) {
				//Parse the score from a string to an int
				for (int i = 0; i < line.length(); i++) {
					highscore *= 10;
					switch (line[i]) {
					case '0':
						highscore += 0;
						break;
					case '1':
						highscore += 1;
						break;
					case '2':
						highscore += 2;
						break;
					case '3':
						highscore += 3;
						break;
					case '4':
						highscore += 4;
						break;
					case '5':
						highscore += 5;
						break;
					case '6':
						highscore += 6;
						break;
					case '7':
						highscore += 7;
						break;
					case '8':
						highscore += 8;
						break;
					case '9':
						highscore += 9;
						break;
					}
				}
				file.close();
			}
		}

		return highscore;
	}
	//Record high score
	void recordHighScore() {
		if (getHighScore() < score) {
			//Record the score
			std::ofstream file;
			file.open("highscore.txt", std::ofstream::out | std::ofstream::trunc);
			file << std::to_string(score);
			file.close();
		}
	}
public:
	void draw(HDC hdc) {
		//Draw score text
		SetTextColor(hdc, RGB(0, 255, 0));
		SetBkColor(hdc, RGB(0, 0, 0));
		std::stringstream scoretext;
		scoretext << "SCORE: " << score;
		std::string text = scoretext.str();
		TextOut(hdc, 4, 4, text.c_str(), text.length());
		//Tell the player how many lives they have left
		std::stringstream livestext;
		livestext << "LIVES: " << player.lives;
		text = livestext.str();
		TextOut(hdc, 4, 20, text.c_str(), text.length());
		//Draw the highscore text
		std::stringstream highscoretxt;
		highscoretxt << "HIGH: " << getHighScore();
		text = highscoretxt.str();
		TextOut(hdc, 4, 36, text.c_str(), text.length());

		//Draw the player
		player.drawSprite(hdc);

		//Draw the aliens
		for (auto alien : aliens) {
			alien.drawSprite(hdc);
		}
		//Draw the bullets
		for (auto bullet : bullets) {
			bullet.drawSprite(hdc);
		}
		for (auto bullet : alienbullets) {
			bullet.drawSprite(hdc);
		}
		//Draw the walls
		for (auto wallpixel : wallpixels) {
			wallpixel.drawSprite(hdc);
		}

		//Draw the ufo
		ufo.drawSprite(hdc);
	}

	void update() {
		player.updateSprite();
		//If the player hits space, generate a bullet
		if (GetAsyncKeyState(VK_SPACE) && player.framesUntilNextShot <= 0 && !player.hit) {
			Bullet tempBullet = Bullet(player.position.x+6 * pixelSize, player.position.y - 6 * pixelSize);
			bullets.push_back(tempBullet);
			player.framesUntilNextShot = 50;
		}

		//Update the aliens
		for (std::vector<Alien>::iterator it1 = aliens.begin(); it1 != aliens.end(); it1++) {
			Alien temp = *it1;
			temp.updateSprite();
			*it1 = temp;

			//Check if the alien got hit by a bullet
			bool hit = false;
			for (std::vector<Bullet>::iterator it2 = bullets.begin(); it2 != bullets.end(); it2++) {
				Bullet tempbullet = *it2;
				//Collision logic
				if (temp.position.x - tempbullet.dimensions.x <= tempbullet.position.x &&
					temp.position.x + temp.dimensions.x >= tempbullet.position.x &&
					temp.position.y - tempbullet.dimensions.y <= tempbullet.position.y &&
					temp.position.y + temp.dimensions.y >= tempbullet.position.y) {
					bullets.erase(it2);
					hit = true;

					player.framesUntilNextShot = 0;
					break;
				}
			}
			//If the alien was hit, remove it from the alien vector
			if (hit) {
				score += temp.value;
				aliens.erase(it1);
				break;
			}
		}
		//Check if the alien is at the edge of the screen
		bool atEdge = false;
		for (int i = 0; i < aliens.size(); i++) {
			Alien temp = aliens.at(i);
			//Check if any aliens are at the edge of the screen
			if (temp.position.x > 820 || temp.position.x < 20) {
				atEdge = true;
				break;
			}
		}
		if (atEdge) {
			//Make sure that no aliens are below y=320
			bool canMove = true;
			for (int i = 0; i < aliens.size(); i++) {
				Alien temp = aliens.at(i);
				if (temp.position.y > 380) {
					canMove = false;
					break;
				}
			}
			for (int i = 0; i < aliens.size(); i++) {
				Alien temp = aliens.at(i);
				//move down
				if (canMove) {
					temp.position.y += 2 * pixelSize;
				}
				//Reverse velocity
				temp.velocity *= -1.0f;
				temp.updateSprite();
				aliens.at(i) = temp;
			}
		}

		//Update the bullets
		for (std::vector<Bullet>::iterator it = bullets.begin(); it != bullets.end(); it++) {
			Bullet temp = *it;
			temp.updateSprite();
			*it = temp;
			//Check if the bullet hit the UFO
			if (temp.position.x - ufo.dimensions.x <= ufo.position.x &&
				temp.position.x + ufo.dimensions.x >= ufo.position.x &&
				temp.position.y - ufo.dimensions.y <= ufo.position.y &&
				temp.position.y + temp.dimensions.y >= ufo.position.y) {
				ufo.position.x = -2400.0f;
				score += (rand() % 300 + 300);
				bullets.erase(it);
				break;
			}
			bool hitwall = false;
			//Destroy any walls hit by the player's bullet
			while (true) {
				bool foundHit = false;
				for (std::vector<WallPixel>::iterator it2 = wallpixels.begin(); it2 != wallpixels.end(); it2++) {
					WallPixel tempWallPixel = *it2;

					if (temp.position.x - tempWallPixel.dimensions.x <= tempWallPixel.position.x &&
						temp.position.x + tempWallPixel.dimensions.x >= tempWallPixel.position.x &&
						temp.position.y - tempWallPixel.dimensions.y <= tempWallPixel.position.y &&
						temp.position.y + temp.dimensions.y >= tempWallPixel.position.y) {
						wallpixels.erase(it2);
						foundHit = true;
						hitwall = true;
						break;
					}
				}
				if (!foundHit) {
					break;
				}
			}
			//If the bullet hit a wall, destroy it
			if (hitwall) {
				player.framesUntilNextShot = 6;
				bullets.erase(it);
				break;
			}
		}
		//Remove any bullets that are past the screen
		for (std::vector<Bullet>::iterator it = bullets.begin(); it != bullets.end(); it++) {
			try {
				Bullet temp = *it;
				if (temp.position.y <= -64) {
					bullets.erase(it);
					break;
				}
			}
			catch (std::out_of_range) {
				break;
			}
		}
		//Update the alien bullets
		for (std::vector<AlienBullet>::iterator it = alienbullets.begin(); it != alienbullets.end(); it++) {
			AlienBullet temp = *it;
			if (temp.position.y > 900) {
				alienbullets.erase(it);
				break;
			}
			temp.updateSprite();
			bool hitwall = false;
			//Check if the player got hit
			if (temp.position.x - player.dimensions.x <= player.position.x &&
				temp.position.x + temp.dimensions.x >= player.position.x &&
				temp.position.y - player.dimensions.y <= player.position.y &&
				temp.position.y + temp.dimensions.y >= player.position.y &&
				!player.hit) {
				player.hit = true;
				//Remove the bullet
				alienbullets.erase(it);
				break;
			}
			//Destroy any wall pixels hit by an alien bullet
			bool detectedHitWall = false;
			while (true) {
				bool foundHit = false;
				for (std::vector<WallPixel>::iterator it2 = wallpixels.begin(); it2 != wallpixels.end(); it2++) {
					WallPixel tempWallPixel = *it2;

					if (temp.position.x - tempWallPixel.dimensions.x <= tempWallPixel.position.x &&
						temp.position.x + tempWallPixel.dimensions.x >= tempWallPixel.position.x &&
						temp.position.y - tempWallPixel.dimensions.y <= tempWallPixel.position.y &&
						temp.position.y + temp.dimensions.y >= tempWallPixel.position.y) {
						wallpixels.erase(it2);
						hitwall = true;
						foundHit = true;
						detectedHitWall = true;
						break;
					}
					else if (std::sqrt(pow(tempWallPixel.position.x - temp.position.x, 2) +
						pow(tempWallPixel.position.y - temp.position.y, 2)) < pixelSize * 3 && detectedHitWall) {
						wallpixels.erase(it2);
						hitwall = true;
						foundHit = true;
						break;
					}
				}
				if (!foundHit) {
					break;
				}
			}
			if (hitwall) {
				alienbullets.erase(it);
				break;
			}
			*it = temp;
		}

		//have the aliens shoot you
		if (timeUntilNextAlienShot <= 0 && aliens.size() > 0) {
			int randomIndex = rand() % (aliens.size());
			Alien shooter = aliens.at(randomIndex);
			AlienBullet tempBullet = AlienBullet(shooter.position.x + 5.5f * pixelSize, shooter.position.y + 4 * pixelSize);
			alienbullets.push_back(tempBullet);
			timeUntilNextAlienShot = 40;
		}
		else {
			timeUntilNextAlienShot--;
		}

		//Check if the player killed all the aliens
		if (aliens.size() <= 0) {
			spawnWave();
		}

		//Update the UFO
		ufo.updateSprite();

		//Record the highscore
		recordHighScore();
	}

	//Constructor
	Game() {
		srand(time(NULL));
		spawnWave();

		//Generate the "walls"
		char wall[24][25] = {
			"....################....",
			"...##################...",
			"..####################..",
			".######################.",
			"########################",
			"########################",
			"########################",
			"##########....##########",
			"#########......#########",
			"########........########",
			"#######..........#######",
			"######............######",
			"######............######",
			"######............######",
			"######............######",
			"######............######",
			"######............######",
		};

		for (int x = 0; x < 4; x++) {
			for (int i = 0; i < 24; i++) {
				for (int j = 0; j < 25; j++) {
					if (wall[i][j] == '#') {
						WallPixel temp = WallPixel(pixelSize * j + 100 + 200*x, pixelSize * i + 400 + 60);
						wallpixels.push_back(temp);
					}
					else {
						continue;
					}
				}
			}
		}
	}
};
