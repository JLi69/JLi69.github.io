#include <windows.h>
#pragma once

const float pixelSize = 4.0f;

struct Vector2D {
	float x = 0.0f, y = 0.0f;

	//Vector addition
	Vector2D operator + (Vector2D v) {
		Vector2D result = { this->x + v.x, this->y + v.y };
		return result;
	}
	void operator += (Vector2D v) {
		this->x += v.x;
		this->y += v.y;
	}
	//Vector subtraction
	Vector2D operator - (Vector2D v) {
		Vector2D result = { this->x - v.x, this->y - v.y };
		return result;
	}
	void operator -= (Vector2D v) {
		this->x -= v.x;
		this->y -= v.y;
	}
	//Multiply by a scaler
	Vector2D operator * (float n) {
		Vector2D result = { this->x *n, this->y*n };
		return result;
	}
	void operator *= (float n) {
		this->x *= n;
		this->y *= n;
	}
};

class Sprite {
public:
	//Position of sprite represented as a vector
	Vector2D position;
	//The dimensions of sprite represented as a vector
	Vector2D dimensions;
	//The velocity of sprite represented as a vector
	Vector2D velocity;

	//Draw the sprite
	virtual void drawSprite(HDC hdc) {}
	//Update the sprite
	virtual void updateSprite() {
		position += velocity;
	}
};

class Alien : public Sprite {
private:
	int type = 0;
public:
	int value = 0;
	void drawSprite(HDC hdc) override {
		if (type == 0) {
			char img[8][11] = {
			"....##....",
			"...####...",
			"..######..",
			".##.##.##.",
			".########.",
			"...#..#...",
			"..#.##.#..",
			".#.#..#.#."
			};

			for (int i = 0; i < 8; i++) {
				for (int j = 0; j < 10; j++) {
					if (img[i][j] == '#') {
						RECT r = { position.x + j * pixelSize,
							position.y + i * pixelSize,
							position.x + j * pixelSize + pixelSize,
							position.y + i * pixelSize + pixelSize };
						HBRUSH brush = CreateSolidBrush(RGB(255, 255, 255));
						FillRect(hdc, &r, brush);
						DeleteObject(brush);
					}
					else {
						continue;
					}
				}
			}
		}
		else if (type == 1) {
			char img[8][11] = {
			".#......#.",
			"..#....#..",
			"..######..",
			".##.##.##.",
			"##########",
			"#.######.#",
			"#.#....#.#",
			"...#..#..."
			};

			for (int i = 0; i < 8; i++) {
				for (int j = 0; j < 10; j++) {
					if (img[i][j] == '#') {
						RECT r = { position.x + j * pixelSize,
							position.y + i * pixelSize,
							position.x + j * pixelSize + pixelSize,
							position.y + i * pixelSize + pixelSize };
						HBRUSH brush = CreateSolidBrush(RGB(255, 255, 255));
						FillRect(hdc, &r, brush);
						DeleteObject(brush);
					}
					else {
						continue;
					}
				}
			}
		}
		else {
			char img[8][13] = {
			"....####....",
			".##########.",
			"############",
			"###..##..###",
			"############",
			"..###..###..",
			".##..##..##.",
			"..##....##.."
			};

			for (int i = 0; i < 8; i++) {
				for (int j = 0; j < 12; j++) {
					if (img[i][j] == '#') {
						RECT r = { position.x + j * pixelSize - pixelSize/2,
							position.y + i * pixelSize,
							position.x + j * pixelSize + pixelSize - pixelSize / 2,
							position.y + i * pixelSize + pixelSize };
						HBRUSH brush = CreateSolidBrush(RGB(255, 255, 255));
						FillRect(hdc, &r, brush);
						DeleteObject(brush);
					}
					else {
						continue;
					}
				}
			}
		}
	}
	//Constructor
	Alien(float X, float Y) {
		position.x = X;
		position.y = Y;

		dimensions.x = 10 * pixelSize;
		dimensions.y = 8 * pixelSize;

		velocity.x = 1.0f;

		value = 10;
	}

	Alien(float X, float Y, int TYPE) {
		position.x = X;
		position.y = Y;

		dimensions.x = 10 * pixelSize;
		dimensions.y = 8 * pixelSize;

		velocity.x = 1.0f;

		type = TYPE;
		//Set the value of the alien
		if (type == 0) {
			value = 30;
		}
		else if (type == 1) {
			value = 20;
		}
		else {
			value = 10;
		}
	}
};

class Player : public Sprite {
private:
	int framesUntilRespawn = 0;
public:
	//keep track of the time until next shot
	int framesUntilNextShot = 0;
	//Keep track of if the player got hit
	bool hit = false;
	int lives = 2;

	void drawSprite(HDC hdc) override {
		if (!hit) {
			char img[8][14] = {
			"......#......",
			".....###.....",
			".....###.....",
			".###########.",
			"#############",
			"#############",
			"#############",
			"#############"
			};

			for (int i = 0; i < 8; i++) {
				for (int j = 0; j < 14; j++) {
					if (img[i][j] == '#') {
						RECT r = { position.x + j * pixelSize,
							position.y + i * pixelSize,
							position.x + j * pixelSize + pixelSize,
							position.y + i * pixelSize + pixelSize };
						HBRUSH brush = CreateSolidBrush(RGB(0, 255, 0));
						FillRect(hdc, &r, brush);
						DeleteObject(brush);
					}
					else {
						continue;
					}
				}
			}
		}
		else {
			char img[8][14] = {
			".............",
			".............",
			"...#.....#...",
			"..........#..",
			".#..#..##....",
			"...#.#.#.#...",
			".#####.#..#..",
			"#########.#.#"
			};

			for (int i = 0; i < 8; i++) {
				for (int j = 0; j < 14; j++) {
					if (img[i][j] == '#') {
						RECT r = { position.x + j * pixelSize,
							position.y + i * pixelSize,
							position.x + j * pixelSize + pixelSize,
							position.y + i * pixelSize + pixelSize };
						HBRUSH brush = CreateSolidBrush(RGB(0, 255, 0));
						FillRect(hdc, &r, brush);
						DeleteObject(brush);
					}
					else {
						continue;
					}
				}
			}
		}
	}
	//Update the player
	void updateSprite() override {
		//If the player is out of lives, don't run the function
		if (lives <= 0) {
			return;
		}
		//Respawn the player
		if (hit && framesUntilRespawn == 0) {
			lives--;
			framesUntilRespawn = 70;
		}
		else if (framesUntilRespawn > 1) {
			framesUntilRespawn--;
		}
		else if (framesUntilRespawn == 1) {
			hit = false;
			framesUntilRespawn = 0;
		}
		//Don't update the player if they have been hit
		if (hit) {
			return;
		}
		//Keyboard input
		if (GetAsyncKeyState(VK_LEFT)) {
			velocity.x = -10.0f;
		}
		else if (GetAsyncKeyState(VK_RIGHT)) {
			velocity.x = 10.0f;
		}
		else {
			velocity.x = 0.0f;
			velocity.y = 0.0f;
		}
		//Add the velocity vector the position vector
		position += velocity;

		//Weapon cooldown
		if (framesUntilNextShot > 0) {
			framesUntilNextShot--;
		}
	}
	//Constructor
	Player(float X, float Y) {
		position.x = X;
		position.y = Y;

		dimensions.x = 13 * pixelSize;
		dimensions.y = 8 * pixelSize;
	}
};

class Bullet : public Sprite {
public:
	void drawSprite(HDC hdc) override {
		char img[8][14] = {
			"#............",
			"#............",
			"#............",
			"#............",
			".............",
			".............",
			".............",
			"............."
		};

		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 14; j++) {
				if (img[i][j] == '#') {
					RECT r = { position.x + j * pixelSize,
						position.y + i * pixelSize,
						position.x + j * pixelSize + pixelSize,
						position.y + i * pixelSize + pixelSize };
					HBRUSH brush = CreateSolidBrush(RGB(0, 255, 0));
					FillRect(hdc, &r, brush);
					DeleteObject(brush);
				}
				else {
					continue;
				}
			}
		}
	}

	Bullet(float X, float Y) {
		position.x = X;
		position.y = Y;

		velocity.y = -10.0f;

		dimensions.x = pixelSize;
		dimensions.y = pixelSize * 4;
	}
};

class AlienBullet : public Sprite {
public:
	void drawSprite(HDC hdc) override {
		char img[8][14] = {
			"#............",
			".#...........",
			"#............",
			".#...........",
			".............",
			".............",
			".............",
			"............."
		};

		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 14; j++) {
				if (img[i][j] == '#') {
					RECT r = { position.x + j * pixelSize,
						position.y + i * pixelSize,
						position.x + j * pixelSize + pixelSize,
						position.y + i * pixelSize + pixelSize };
					HBRUSH brush = CreateSolidBrush(RGB(255, 255, 255));
					FillRect(hdc, &r, brush);
					DeleteObject(brush);
				}
				else {
					continue;
				}
			}
		}
	}

	AlienBullet(float X, float Y) {
		position.x = X;
		position.y = Y;

		velocity.y = 10.0f;

		dimensions.x = pixelSize;
		dimensions.y = pixelSize * 4;
	}
};

class WallPixel : public Sprite {
public:
	void drawSprite(HDC hdc) override {
		RECT r = { position.x,
					position.y,
					position.x + pixelSize,
					position.y + pixelSize };
		HBRUSH brush = CreateSolidBrush(RGB(0, 255, 0));
		FillRect(hdc, &r, brush);
		DeleteObject(brush);
	}

	WallPixel(float X, float Y) {
		position.x = X;
		position.y = Y;

		dimensions.x = pixelSize;
		dimensions.y = pixelSize;
	}
};

class UFO : public Sprite {
public:
	void drawSprite(HDC hdc) override {
		char img[8][16] = {
			"...............",
			".....#####.....",
			"...#########...",
			"..###########..",
			".##.#.#.#.#.##.",
			"###############",
			"..###.....###..",
			"...#.......#..."
		};

		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 16; j++) {
				if (img[i][j] == '#') {
					RECT r = { position.x + j * pixelSize,
						position.y + i * pixelSize,
						position.x + j * pixelSize + pixelSize,
						position.y + i * pixelSize + pixelSize };
					HBRUSH brush = CreateSolidBrush(RGB(255, 0, 0));
					FillRect(hdc, &r, brush);
					DeleteObject(brush);
				}
				else {
					continue;
				}
			}
		}
	}

	void updateSprite() override {
		position += velocity;

		if (position.x > 2400) {
			position.x = -1600;
		}
	}

	UFO(float X, float Y) {
		position.x = X;
		position.y = Y;

		dimensions.x = 15*pixelSize;
		dimensions.y = 8*pixelSize;

		velocity.x = 4.0f;
	}
};