_G.love = require('love')
_G.menu = require('src.menu')
_G.game = require('src.game')
levels = require('src.levels')
local GAME_TITLE = 'Sokobash'
local current_screen = menu.INTRO_SCREEN
local paused = false
math.randomseed(os.time())
local menu_animation = { x = math.random() * 800, y = -48 }

-- Function activates when button is pressed
function love.mousepressed(x, y, button, istouch)	
	if button == 1 and 
		menu.mouse_hovering_button(credits_button, x, y) and 
		current_screen == menu.MAIN_MENU_SCREEN then
		current_screen = menu.CREDITS_SCREEN	
		click:play()
	end
	
	if button == 1 and 
		menu.mouse_hovering_button(play_button, x, y) and 
		current_screen == menu.MAIN_MENU_SCREEN then
		current_screen = menu.LEVEL_SELECT	
		click:play()
	end

	if button == 1 and
		menu.mouse_hovering_button(goto_main_menu, x, y) and
		(current_screen == menu.CREDITS_SCREEN or
		(current_screen == menu.GAME_SCREEN and (paused or game.game_over or game.win_level)) or current_screen == menu.LEVEL_SELECT) then
		current_screen = menu.MAIN_MENU_SCREEN	
		game.reset()
		paused = false	
		click:play()
	end

	if button == 1 and menu.mouse_hovering_button(restart, x, y) and game.game_over then
		game.reset()
		click:play()
	end

	if button == 1 and menu.mouse_hovering_button(next_level, x, y) and game.win_level and game.current_level < #levels.levels then
		game.current_level = game.current_level + 1
		game.reset()
		click:play()
	end
	
	if button == 1 and menu.mouse_hovering_button(next_text, x, y) and current_screen == menu.INTRO_SCREEN then
		if menu.current_intro_text == #menu.intro_text then
			current_screen = menu.MAIN_MENU_SCREEN	
			menu.current_intro_text = 0
		end
		menu.current_intro_text = menu.current_intro_text + 1
		click:play()
	end

	if button == 1 and current_screen == menu.LEVEL_SELECT then
		for i, button in ipairs(level_select) do
			if menu.mouse_hovering_button(button, x, y) then
				game.current_level = i
				game.reset()
				current_screen = menu.GAME_SCREEN	
				click:play()
				break
			end
		end
	end
end

function love.keypressed(key, scancode, isrepeat)
	if key == 'escape' and current_screen == menu.GAME_SCREEN then
		paused = not paused
	end
end

-- Load assets and start game
function love.load()
	-- Create window
	love.window.setMode(800, 640)
	love.window.setTitle(GAME_TITLE)
	
	-- Load fonts
	_G.title_font = 
		love.graphics.newFont('assets/fonts/8BitOperator/8bitOperatorPlus-Bold.ttf', 60)
	_G.button_font = 
		love.graphics.newFont('assets/fonts/8BitOperator/8bitOperatorPlus-Regular.ttf', 40)
	_G.medium_font = 
		love.graphics.newFont('assets/fonts/8BitOperator/8bitOperatorPlus-Regular.ttf', 20)

	_G.play_button = 
		menu.create_button(400, 300, 'PLAY', button_font, { 1.0, 1.0, 1.0 }, { 0.5, 0.5, 0.5 })
	_G.credits_button = 
		menu.create_button(400, 360, 'CREDITS', button_font, { 1.0, 1.0, 1.0 }, { 0.5, 0.5, 0.5 })
	_G.goto_main_menu = 
		menu.create_button(400, 500, 'Return to Menu', button_font, { 1.0, 1.0, 1.0 }, { 0.5, 0.5, 0.5 })

	_G.restart = 
		menu.create_button(400, 300, 'Restart', button_font, { 1.0, 1.0, 1.0 }, { 0.5, 0.5, 0.5 })

	_G.next_level = 
		menu.create_button(400, 300, 'Next Level', button_font, { 1.0, 1.0, 1.0 }, { 0.5, 0.5, 0.5 })

	_G.next_text = 
		menu.create_button(700, 540, '-->', button_font, { 1.0, 1.0, 1.0 }, { 0.5, 0.5, 0.5 })

	-- Level select screen
	_G.level_select = {}
	for i = 1, #levels.levels do
		table.insert(level_select, menu.create_button(
			i * 64 + 400 - #levels.levels * 64 / 2 - 32, 350, tostring(i), button_font, { 1.0, 1.0, 1.0 }, { 0.5, 0.5, 0.5 }
		))	
	end

	_G.click = love.audio.newSource("assets/audio/mouseclick.wav", "static")

	game.load_assets()
end

-- Display
function love.draw()
	love.graphics.setColor(0.3, 0.7, 0.9)
	love.graphics.rectangle('fill', 0, 0, 800, 640)

	-- Mouse position
	local mousex, mousey = love.mouse.getPosition()

	if current_screen == menu.INTRO_SCREEN then	
		love.graphics.setColor(1.0, 1.0, 1.0)
		love.graphics.setFont(medium_font)
		love.graphics.printf(menu.intro_text[menu.current_intro_text], 0, 300, 800, 'center')

		menu.draw_button(
			next_text, 
			mousex, 
			mousey 
		)	
	elseif current_screen == menu.MAIN_MENU_SCREEN then
		-- Draw title onto screen
		love.graphics.setColor(1.0, 1.0, 1.0)
		love.graphics.setFont(title_font)
		love.graphics.printf(GAME_TITLE, 0, 50, 800, 'center')
		
		-- Display buttons
		menu.draw_button(
			play_button, 
			mousex, 
			mousey 
		)

		menu.draw_button(
			credits_button, 
			mousex, 
			mousey 
		)
		
		love.graphics.setColor(1.0, 1.0, 1.0)
		love.graphics.draw(
			player_image,
			menu_animation.x,
			menu_animation.y,
			0,
			3)
	elseif current_screen == menu.CREDITS_SCREEN then
		love.graphics.setColor(1.0, 1.0, 1.0)
		love.graphics.setFont(medium_font)
		love.graphics.printf(menu.CREDITS, 0, 50, 800, 'center')
	
		menu.draw_button(
			goto_main_menu, 
			mousex, 
			mousey 
		)
	elseif current_screen == menu.LEVEL_SELECT then
		love.graphics.setColor(1.0, 1.0, 1.0)
		love.graphics.setFont(title_font)
		love.graphics.printf('Level Select', 0, 50, 800, 'center')
		for i, button in ipairs(level_select) do
			menu.draw_button(
				button, 
				mousex, 
				mousey 
			)		
		end

		menu.draw_button(
			goto_main_menu, 
			mousex, 
			mousey 
		)
	elseif current_screen == menu.GAME_SCREEN then	
		-- Display gameobjects if on gameplay screen
		game.display()

		-- Pause menu / Death Screen / Win Screen
		if game.game_over then
			love.graphics.setColor(0.2, 0.2, 0.2, 0.75)
			love.graphics.rectangle('fill', 0, 0, 800, 640)
			love.graphics.setColor(1.0, 1.0, 1.0)
			love.graphics.setFont(title_font)
			love.graphics.printf('GAME OVER!', 0, 50, 800, 'center')	
	
			menu.draw_button(
				restart, 
				mousex, 
				mousey 
			)

			menu.draw_button(
				goto_main_menu, 
				mousex, 
				mousey 
			)
		elseif paused then			
			love.graphics.setColor(0.2, 0.2, 0.2, 0.75)
			love.graphics.rectangle('fill', 0, 0, 800, 640)
			love.graphics.setColor(1.0, 1.0, 1.0)
			love.graphics.setFont(title_font)
			love.graphics.printf('Paused', 0, 50, 800, 'center')	
		
			menu.draw_button(
				goto_main_menu, 
				mousex, 
				mousey 
			)
		elseif game.win_level then
			love.graphics.setColor(0.2, 0.2, 0.2, 0.75)
			love.graphics.rectangle('fill', 0, 0, 800, 640)
			love.graphics.setColor(1.0, 1.0, 1.0)
			love.graphics.setFont(title_font)
			love.graphics.printf('Level complete!', 0, 50, 800, 'center')

			if game.current_level < #levels.levels then
				menu.draw_button(
					next_level, 
					mousex, 
					mousey 
				)	
			end

			menu.draw_button(
				goto_main_menu, 
				mousex, 
				mousey 
			)
		end
	end
end

-- Game update loop
function love.update(dt)
	menu_animation.y = menu_animation.y + 240 * dt
	if menu_animation.y > 650 then
		menu_animation.y = -48
		menu_animation.x = math.random() * 800
	end

	if current_screen == menu.GAME_SCREEN and not paused then
		game.update(dt)
	end
end
