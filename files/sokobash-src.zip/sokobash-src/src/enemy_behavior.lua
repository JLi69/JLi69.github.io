local levels = require('src.levels')
local enemy_behavior = {}

function enemy_behavior.getdirection(enemy)
	local neighbor_x = { 1, 0, -1, 0 }
	local neighbor_y = { 0, -1, 0, 1 }
	return neighbor_x[enemy.direction + 1], neighbor_y[enemy.direction + 1]
end

function enemy_behavior.rotate_until_can_move(enemy, level_num)
	local neighbor_x = { 1, 0, -1, 0 }
	local neighbor_y = { 0, -1, 0, 1 }	
	local tiles_checked = 0

	while levels.get_tile(level_num, 
		enemy.x + neighbor_x[enemy.direction + 1],
		enemy.y + neighbor_y[enemy.direction + 1]) ~= '.' and 
		levels.get_tile(level_num, 
		enemy.x + neighbor_x[enemy.direction + 1],
		enemy.y + neighbor_y[enemy.direction + 1]) ~= '!' or
		(enemy.x + neighbor_x[enemy.direction + 1] == enemy.prevx and
		enemy.y + neighbor_y[enemy.direction + 1] == enemy.prevy) and
		tiles_checked < 4 do
		enemy.direction = enemy.direction + enemy.rotation_direction
		enemy.direction = enemy.direction % 4
		tiles_checked = tiles_checked + 1
	end
end

function enemy_behavior.rotate_until_can_move_player(enemy, level_num, player)
	local neighbor_x = { 1, 0, -1, 0 }
	local neighbor_y = { 0, -1, 0, 1 }	
	local tiles_checked = 0

	while ((levels.get_tile(level_num, 
		enemy.x + neighbor_x[enemy.direction + 1],
		enemy.y + neighbor_y[enemy.direction + 1]) ~= '.' and 
		levels.get_tile(level_num, 
		enemy.x + neighbor_x[enemy.direction + 1],
		enemy.y + neighbor_y[enemy.direction + 1]) ~= '!') or
		(enemy.x + neighbor_x[enemy.direction + 1] == player.x and
		enemy.y + neighbor_y[enemy.direction + 1] == player.y) or
		(enemy.x + neighbor_x[enemy.direction + 1] == enemy.prevx and
		enemy.y + neighbor_y[enemy.direction + 1] == enemy.prevy)) and	
		tiles_checked < 4 do
		enemy.direction = enemy.direction + enemy.rotation_direction
		enemy.direction = enemy.direction % 4
		tiles_checked = tiles_checked + 1
	end
end

function enemy_behavior.move_enemy(enemy, level_num)	
	enemy_behavior.rotate_until_can_move(enemy, level_num)

	local prevx = enemy.x
	local prevy = enemy.y

	if enemy.direction == 0 then
		enemy.x = enemy.x + 1
	elseif enemy.direction == 1 then
		enemy.y = enemy.y - 1
	elseif enemy.direction == 2 then
		enemy.x = enemy.x - 1
	elseif enemy.direction == 3 then
		enemy.y = enemy.y + 1
	end

	enemy.prevx = prevx
	enemy.prevy = prevy
end

return enemy_behavior
