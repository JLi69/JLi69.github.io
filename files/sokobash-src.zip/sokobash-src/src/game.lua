local love = require('love')
local menu = require('src.menu')
local levels = require('src.levels')
local enemy_behavior = require('src.enemy_behavior')
local game = {}

game.current_level = 1
game.game_over = false
game.win_level = false
game.show_player = true
game.enemy_update_timer = 0.0
game.enemy_update_rate = 1.0
game.moves_left = levels.levels[game.current_level].moves

local CHARGE_RATE = 0.2
local FRICTION_RATE = 8.0
local MAX_SPEED = 24.0

game.player = {
	x = levels.levels[game.current_level].startx,
	y = levels.levels[game.current_level].starty,
	chargex = 0,
	chargey = 0,
	speedx = 0,
	speedy = 0
}

local particles = {}

function copy_enemy_table(level_num)
	local enemies = {}
	for i, enemy in ipairs(levels.levels[game.current_level].enemy_start_positions) do
		enemy2 = {}
		for k, v in pairs(enemy) do
			enemy2[k] = v
		end
		enemies[i] = enemy2
	end
	return enemies
end

game.enemies = copy_enemy_table(game.current_level)

function game.reset()
	game.game_over = false	
	game.win_level = false
	game.show_player = true
	game.player = {
		x = levels.levels[game.current_level].startx,
		y = levels.levels[game.current_level].starty,
		chargex = 0,
		chargey = 0,
		speedx = 0,
		speedy = 0
	}
	game.enemies = copy_enemy_table(game.current_level)
	game.enemy_update_timer = 0
	particles = {}	
	game.moves_left = levels.levels[game.current_level].moves
end

function newAnimation(image, width, height, duration)
	local animation = {}

	animation.spriteSheet = image
	animation.quads = {}

	for y = 0, image:getHeight() - height, height do
		for x = 0, image:getWidth() - width, width do
			animation.quads[#animation.quads + 1] = 
				love.graphics.newQuad(x, y, width, height, image:getDimensions())
		end
	end

	animation.duration = duration or 1
	animation.currentTime = 0

	return animation
end


function game.load_assets()
	love.graphics.setDefaultFilter('nearest')
	_G.player_image = love.graphics.newImage('assets/images/player.png')
	_G.wall_image = love.graphics.newImage('assets/images/wall.png')
	_G.floor_image = love.graphics.newImage('assets/images/floor.png')
	_G.goal_image = love.graphics.newImage('assets/images/goal.png')	
	_G.spike_image = love.graphics.newImage('assets/images/spike.png')
	_G.enemy_animation = newAnimation(love.graphics.newImage("assets/images/enemy.png"), 16, 16, 0.7)
	_G.squish = love.audio.newSource("assets/audio/impactsplat01.mp3.flac", "static")
	_G.crate_break = love.audio.newSource("assets/audio/66779__kevinkace__crate-break-3.wav", "static")
end

function game.display()
	-- Display the level
	for y = 1, levels.levels[game.current_level].height do
		for x = 1, levels.levels[game.current_level].width do
			local tile = levels.get_tile(game.current_level, x, y)
			local screenx = x * 32 - 32 + 400 - levels.levels[game.current_level].width * 16
			local screeny = y * 32 - 32 + 320 - levels.levels[game.current_level].height * 16

			love.graphics.setColor(1.0, 1.0, 1.0)
			if tile == '#' then
				love.graphics.draw(
					wall_image,		
					screenx,
					screeny,
					0,
					2
				)
			elseif tile == '.' then
				love.graphics.draw(
					floor_image,		
					screenx,
					screeny,
					0,
					2
				)
			elseif tile == '!' then
				love.graphics.draw(
					goal_image,		
					screenx,
					screeny,
					0,
					2
				)
			elseif tile == '^' then
				love.graphics.draw(
					spike_image,		
					screenx,
					screeny,
					0,
					2
				)
			end
		end
	end

	-- Display enemies
	for i, enemy in ipairs(game.enemies) do
		if not enemy.dead then
			love.graphics.setColor(1.0, 1.0, 1.0)
			local frame = math.floor(
				enemy_animation.currentTime / enemy_animation.duration * 2) + enemy.direction * 4
			if game.enemy_update_timer > 0.7 or game.enemy_update_timer < 0.3 then
				frame = frame + 2
			end
			love.graphics.draw(
				enemy_animation.spriteSheet,
				enemy_animation.quads[frame + 1],
				enemy.x * 32 - 32 + 400 - levels.levels[game.current_level].width * 16,
				enemy.y * 32 - 32 + 320 - levels.levels[game.current_level].height * 16,
				0,
				2
			)
		end	
	end

	-- Display blood particles		
	love.graphics.setColor(1.0, 0.0, 0.0)
	for i, particle in ipairs(particles) do	
		if particle.dist_travelled <= 3.0 then
			love.graphics.rectangle(
				'fill',
				particle.x * 32 - 32 + 400 - levels.levels[game.current_level].width * 16,
				particle.y * 32 - 32 + 320 - levels.levels[game.current_level].height * 16,
				8,
				8
			)	
		end	
	end

	-- Display the player	
	if game.show_player then
		love.graphics.setColor(1.0, 1.0, 1.0)
		love.graphics.draw(
			player_image,		
			game.player.x * 32 - 32 + 400 - levels.levels[game.current_level].width * 16,
			game.player.y * 32 - 32 + 320 - levels.levels[game.current_level].height * 16,
			0,
			2
		)
	end

	if levels.get_tile(game.current_level, math.floor(game.player.x + 0.5), math.floor(game.player.y + 0.5)) == 'x' then
		game.show_player = false
	end

	if game.player.chargex > 0 then		
		love.graphics.setColor(1.0, 0.0, 0.0)
		love.graphics.rectangle(
			'fill', 
			game.player.x * 32 - 32 + 400 - levels.levels[game.current_level].width * 16 + 40,
			game.player.y * 32 - 32 + 320 - levels.levels[game.current_level].height * 16 + 14,
			32,
			4
		)
		love.graphics.setColor(0.0, 1.0, 0.0)
		love.graphics.rectangle(
			'fill', 
			game.player.x * 32 - 32 + 400 - levels.levels[game.current_level].width * 16 + 40,
			game.player.y * 32 - 32 + 320 - levels.levels[game.current_level].height * 16 + 14,
			32 * math.abs(game.player.chargex),
			4
		)
	elseif game.player.chargex < 0 then
		love.graphics.setColor(1.0, 0.0, 0.0)
		love.graphics.rectangle(
			'fill', 
			game.player.x * 32 - 32 + 400 - levels.levels[game.current_level].width * 16 - 40,
			game.player.y * 32 - 32 + 320 - levels.levels[game.current_level].height * 16 + 14,
			32,
			4
		)
		love.graphics.setColor(0.0, 1.0, 0.0)
		love.graphics.rectangle(
			'fill', 
			game.player.x * 32 - 32 + 400 - levels.levels[game.current_level].width * 16 - 40,
			game.player.y * 32 - 32 + 320 - levels.levels[game.current_level].height * 16 + 14,
			32 * math.abs(game.player.chargex),
			4
		)
	end

	if game.player.chargey > 0 then
		love.graphics.setColor(1.0, 0.0, 0.0)
		love.graphics.rectangle(
			'fill', 
			game.player.x * 32 - 32 + 400 - levels.levels[game.current_level].width * 16,
			game.player.y * 32 - 32 + 320 - levels.levels[game.current_level].height * 16 + 40,
			32,
			4	
		)
		love.graphics.setColor(0.0, 1.0, 0.0)
		love.graphics.rectangle(
			'fill', 
			game.player.x * 32 - 32 + 400 - levels.levels[game.current_level].width * 16,
			game.player.y * 32 - 32 + 320 - levels.levels[game.current_level].height * 16 + 40,
			32 * math.abs(game.player.chargey),
			4
		)
	elseif game.player.chargey < 0 then
		love.graphics.setColor(1.0, 0.0, 0.0)
		love.graphics.rectangle(
			'fill', 
			game.player.x * 32 - 32 + 400 - levels.levels[game.current_level].width * 16,
			game.player.y * 32 - 32 + 320 - levels.levels[game.current_level].height * 16 - 12,
			32,
			4	
		)
		love.graphics.setColor(0.0, 1.0, 0.0)
		love.graphics.rectangle(
			'fill', 
			game.player.x * 32 - 32 + 400 - levels.levels[game.current_level].width * 16,
			game.player.y * 32 - 32 + 320 - levels.levels[game.current_level].height * 16 - 12,
			32 * math.abs(game.player.chargey),
			4
		)
	end

	if game.player.chargex > 1.0 then
		game.player.chargex = 1.0
	elseif game.player.chargex < -1.0 then
		game.player.chargex = -1.0
	end

	if game.player.chargey > 1.0 then
		game.player.chargey = 1.0
	elseif game.player.chargey < -1.0 then
		game.player.chargey = -1.0
	end

	love.graphics.setFont(medium_font)
	love.graphics.setColor(1.0, 1.0, 1.0)
	love.graphics.print("Moves left: " .. tostring(game.moves_left), 16, 16)
end

function game.handle_key_input(dt)
	if love.keyboard.isDown('left') then
		if game.player.chargex > 0 then
			game.player.chargex = 0
		end
		game.player.chargex = game.player.chargex - (math.pow(CHARGE_RATE, -game.player.chargex) - CHARGE_RATE) * dt
		game.player.chargey = 0
	elseif love.keyboard.isDown('right') then 
		if game.player.chargex < 0 then
			game.player.chargex = 0
		end
		game.player.chargex = game.player.chargex + (math.pow(CHARGE_RATE, game.player.chargex) - CHARGE_RATE) * dt
		game.player.chargey = 0
	elseif love.keyboard.isDown('up') then
		game.player.chargex = 0
		if game.player.chargey > 0 then
			game.player.chargey = 0
		end
		game.player.chargey = game.player.chargey - (math.pow(CHARGE_RATE, -game.player.chargey) - CHARGE_RATE) * dt
	elseif love.keyboard.isDown('down') then
		game.player.chargex = 0
		if game.player.chargey < 0 then
			game.player.chargey = 0
		end
		game.player.chargey = game.player.chargey + (math.pow(CHARGE_RATE, game.player.chargey) - CHARGE_RATE) * dt
	else
		game.player.speedx = game.player.chargex * MAX_SPEED
		game.player.speedy = game.player.chargey * MAX_SPEED	
		if math.abs(game.player.speedx) > 0.2 or math.abs(game.player.speedy) > 0.2 then
			game.moves_left = game.moves_left - 1
		end
		game.player.chargey = 0
		game.player.chargex = 0
	end
end

function sign(x)
	if x < 0 then
		return -1
	elseif x > 0 then
		return 1
	end
	return 0
end

function game.update(dt)	
	if game.moves_left < 0 and not game.win_level then
		game.moves_left = 0
		game.game_over = true
	end

	-- Mouse position
	local mousex, mousey = love.mouse.getPosition()	

	-- Player movement
	if game.player.speedx == 0 and game.player.speedy == 0 and not game.game_over and not game.win_level then
		game.handle_key_input(dt)
	end
	
	local round_playerx = math.floor(game.player.x + 0.5)
	local round_playery = math.floor(game.player.y + 0.5)
	if levels.get_tile(game.current_level, round_playerx, round_playery) ~= '!' then
		game.player.x = game.player.speedx * dt + game.player.x
		game.player.y = game.player.speedy * dt + game.player.y
	else
		game.player.x = round_playerx
		game.player.y = round_playery
	end

	if game.player.speedx ~= 0 then
		game.player.speedx = game.player.speedx - FRICTION_RATE * sign(game.player.speedx) * dt
	end

	if game.player.speedy ~= 0 then
		game.player.speedy = game.player.speedy - FRICTION_RATE * sign(game.player.speedy) * dt
	end

	-- handle collision
	if levels.get_tile(game.current_level, round_playerx, round_playery) ~= '.' and	
		levels.get_tile(game.current_level, round_playerx, round_playery) ~= '!' and
	    levels.get_tile(game.current_level, round_playerx, round_playery) ~= 'x' and
		levels.get_tile(game.current_level, round_playerx, round_playery) ~= '^' then
		crate_break:play()	
		game.player.x = round_playerx - sign(game.player.speedx)
		game.player.y = round_playery - sign(game.player.speedy)
		game.player.speedx = 0.0
		game.player.speedy = 0.0	
	end

	-- handle collision with enemy
	for i, enemy in ipairs(game.enemies) do
		if enemy.x == round_playerx and enemy.y == round_playery then	
			crate_break:play()
			enemy.x = enemy.x + sign(game.player.speedx)
			enemy.y = enemy.y + sign(game.player.speedy)
			game.player.speedx = game.player.speedx * 0.8
			game.player.speedy = game.player.speedy * 0.8
		end
	end	

	if levels.get_tile(game.current_level, round_playerx, round_playery) == '!' or
	    levels.get_tile(game.current_level, round_playerx, round_playery) == 'x' then
		if not game.game_over then
			crate_break:play()
		end
		game.game_over = true	
	end

	if math.abs(game.player.speedx) < 0.1 then
		game.player.speedx = 0.0
		game.player.x = math.floor(game.player.x + 0.5)
	end
	if math.abs(game.player.speedy) < 0.1 then
		game.player.speedy = 0.0
		game.player.y = math.floor(game.player.y + 0.5)
	end

	-- Update enemies
	local dead_count = 0
	for i, enemy in ipairs(game.enemies) do
		if enemy.dead then
			dead_count = dead_count + 1
		else
			if levels.get_tile(game.current_level, enemy.x, enemy.y) ~= '.' and
				levels.get_tile(game.current_level, enemy.x, enemy.y) ~= '!' then
				squish:play()
				enemy.dead = true
				
				-- Create a bunch of blood particles
				for i = 1, 24 do
					table.insert(particles, { x = enemy.x + 0.5, y = enemy.y + 0.5, angle = math.random() * 3.14159 * 2.0, dist_travelled = 0.0 })
				end
			end
		end	
	end

	for i, particle in ipairs(particles) do
		particle.x = particle.x + math.cos(particle.angle) * 0.15
		particle.y = particle.y + math.sin(particle.angle) * 0.15
		particle.dist_travelled = particle.dist_travelled + 0.15
	end

	if dead_count == #game.enemies then
		game.win_level = true	
	end

	game.enemy_update_timer = game.enemy_update_timer + dt
	if game.enemy_update_timer > game.enemy_update_rate then		
		for i, enemy in ipairs(game.enemies) do	
			if not enemy.dead then
				enemy_behavior.move_enemy(enemy, game.current_level)	
				dx, dy = enemy_behavior.getdirection(enemy)

				local collided_with_enemy = false

				for i2, enemy2 in ipairs(game.enemies) do
					if enemy2.x == enemy.x and enemy2.y == enemy.y and i ~= i2 then
						enemy.x = enemy.x - dx
						enemy.y = enemy.y - dy
						enemy.direction = (enemy.direction + 2) % 4
						collided_with_enemy = true
					end
				end

				if not collided_with_enemy and enemy.x == round_playerx and enemy.y == round_playery then
					-- Attempt to push player
					if (levels.get_tile(game.current_level, enemy.x + dx, enemy.y + dy) == '.' or
						levels.get_tile(game.current_level, enemy.x + dx, enemy.y + dy) == '!' or
						levels.get_tile(game.current_level, enemy.x + dx, enemy.y + dy) == 'x') and
						not game.game_over then
						game.player.speedx = 0
						game.player.speedy = 0
						game.player.x = game.player.x + dx
						game.player.y = game.player.y + dy
					else
						enemy.x = enemy.x - dx
						enemy.y = enemy.y - dy
						enemy_behavior.rotate_until_can_move_player(enemy, game.current_level, game.player)
					end
				end
			end	
		end
		game.enemy_update_timer = 0
	end

	enemy_animation.currentTime = enemy_animation.currentTime + dt
	if enemy_animation.currentTime >= enemy_animation.duration then
		enemy_animation.currentTime = 0.0
	end
end

return game
