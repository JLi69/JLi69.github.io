local levels = {}

--[[
-- # = Wall
-- . = Floor
-- x = pit
-- ^ = spike ! = goal
--]]

levels.levels = {
	{
        level_data =
                "#######"..
                "#....!#"..
                "#.#####"..
                "#.#####"..
                "#.....#"..
                "#######"
        ,
        width = 7,
        height = 6,
        startx = 4,
        starty =  2,
        enemy_start_positions = {
                { x = 4, y = 5, direction = 2, rotation_direction = -1, dead = false },
        },
		moves = 3
	},

	{
        level_data =
                "xxxx###xxxx"..
                "xxxx#!#xxxx"..
                "xxxx#.#xxxx"..
                "#####.#####"..
                "#!.......!#"..
                "#xxxxxxxxx#"..
                "#xxxxxxxxx#"..
                "#xxxxxxxxx#"..
                "###########"
        ,
        width = 11,
        height = 9,
        startx = 6,
        starty =  3,
        enemy_start_positions = {
                { x = 6, y = 2, direction = 3, rotation_direction = 1, dead = false },
        },
		moves = 4
	},	

	{
		level_data =
			"#######x#######"..
			"#^^^^^#x#!!!!!#"..
			"#^^^^^#x#!^^^!#"..
			"#^^^^^#x#!^^^!#"..
			"#^...^#x#!^^^!#"..
			"#^...^#x#!!.!!#"..
			"#^...^#x###.###"..
			"#^.^^^#xxx#.#xx"..
			"##.####xxx#.#xx"..
			"x#.##xxxxx#.#xx"..
			"x#.!#######.#xx"..
			"x#..........#xx"..
			"x##.#######^##x"..
			"x#!.!#xxx#^^^#x"..
			"x#!.!#xxx#!.!#x"..
			"x#!!!#xxx#!^!#x"..
			"x#####xxx#####x"
		,
		width = 15,
		height = 17,
		startx = 4,
		starty =  6,
		enemy_start_positions = {
			{ x = 10, y = 6, direction = 0, rotation_direction = 1, dead = false },
			{ x = 4, y = 15, direction = 0, rotation_direction = 1, dead = false },
			{ x = 12, y = 15, direction = 2, rotation_direction = -1, dead = false },
		},
		moves = 20
	},

	{
		level_data =
			"xx#####xx"..
			"xx#...#xx"..
			"xx#...#xx"..
			"xx#...#xx"..
			"###!!!###"..
			"#!!...!!#"..
			"#!^...^!#"..
			"#!^...^!#"..
			"#!!...!!#"..
			"###!!!###"..
			"xx#...#xx"..
			"xx#...#xx"..
			"xx#...#xx"..
			"xx#####xx"
		,
		width = 9,
		height = 14,
		startx = 5,
		starty =  7,
		enemy_start_positions = {
			{ x = 5, y = 2, direction = 3, rotation_direction = 1, dead = false },
			{ x = 4, y = 2, direction = 3, rotation_direction = 1, dead = false },
			{ x = 6, y = 2, direction = 3, rotation_direction = 1, dead = false },
			{ x = 4, y = 13, direction = 1, rotation_direction = 1, dead = false },
			{ x = 6, y = 13, direction = 1, rotation_direction = 1, dead = false },
			{ x = 5, y = 13, direction = 1, rotation_direction = 1, dead = false },
		},
		moves = 16
	},

	{
		level_data =
			"xx###xxxxxxxxx"..
			"xx#!#xxxxxxxxx"..
			"###.##########"..
			"#!........^^^#"..
			"###.######.###"..
			"#!........^^^#"..
			"###.######.###"..
			"#!........^^^#"..
			"###.######.###"..
			"#!........^^^#"..
			"###.##########"..
			"xx#!#xxxxxxxxx"..
			"xx###xxxxxxxxx"
		,
		width = 14,
		height = 13,
		startx = 11,
		starty =  7,
		enemy_start_positions = {
			{ x = 3, y = 10, direction = 0, rotation_direction = 1, dead = false },
			{ x = 3, y = 4, direction = 0, rotation_direction = 1, dead = false },
			{ x = 3, y = 6, direction = 0, rotation_direction = 1, dead = false },
			{ x = 3, y = 8, direction = 0, rotation_direction = 1, dead = false },
			{ x = 10, y = 4, direction = 2, rotation_direction = 1, dead = false },
			{ x = 10, y = 6, direction = 2, rotation_direction = 1, dead = false },
			{ x = 10, y = 8, direction = 2, rotation_direction = 1, dead = false },
			{ x = 10, y = 10, direction = 2, rotation_direction = 1, dead = false },
		},
		moves = 40
	},

	{
		level_data =
			"#############"..
			"#!!!!!!!!!!!#"..
			"#!.........!#"..
			"#!.........!#"..
			"#!.........!#"..
			"#!!!!.!.!!!!#"..
			"#!###.#.###!#"..
			"#!....#....!#"..
			"#!.^^.#.^^.!#"..
			"#!....#....!#"..
			"#!....#....!#"..
			"##.^^.#.^^.##"..
			"#.!!!.#.!!!.#"..
			"#.###.#.###.#"..
			"#!!!!.!.!!!!#"..
			"#!.........!#"..
			"#!.........!#"..
			"#!.........!#"..
			"#!!!!!!!!!!!#"..
			"#############"
		,
		width = 13,
		height = 20,
		startx = 7,
		starty =  3,
		enemy_start_positions = {
			{ x = 3, y = 3, direction = 0, rotation_direction = -1, dead = false },
			{ x = 11, y = 3, direction = 3, rotation_direction = -1, dead = false },
			{ x = 11, y = 18, direction = 2, rotation_direction = -1, dead = false },
			{ x = 3, y = 18, direction = 1, rotation_direction = -1, dead = false },
			{ x = 4, y = 4, direction = 0, rotation_direction = -1, dead = false },
			{ x = 10, y = 4, direction = 3, rotation_direction = -1, dead = false },
			{ x = 10, y = 17, direction = 2, rotation_direction = -1, dead = false },
			{ x = 4, y = 17, direction = 1, rotation_direction = -1, dead = false },
			{ x = 5, y = 5, direction = 0, rotation_direction = -1, dead = false },
			{ x = 9, y = 5, direction = 3, rotation_direction = -1, dead = false },
			{ x = 9, y = 16, direction = 2, rotation_direction = -1, dead = false },
			{ x = 5, y = 16, direction = 1, rotation_direction = -1, dead = false },
		},
		moves = 64
	},

	{
		level_data =
			"xx.............xx"..
			"x!..............x"..
			"..!.............."..
			"...!xxx...xxx...."..
			"...xxxx...xxxx..."..
			"...xxxx...xxxx..."..
			"...xxxx...xxxx..."..
			"...xxxx...xxxx..."..
			"....xxx...xxx!..."..
			"..............!.."..
			"x..............!x"..
			"xx.............xx"
		,
		width = 17,
		height = 12,
		startx = 9,
		starty =  2,
		enemy_start_positions = {
			{ x = 5, y = 2, direction = 0, rotation_direction = -1, dead = false },
			{ x = 2, y = 8, direction = 1, rotation_direction = -1, dead = false },
			{ x = 16, y = 5, direction = 3, rotation_direction = -1, dead = false },
			{ x = 13, y = 11, direction = 2, rotation_direction = -1, dead = false },
			{ x = 5, y = 3, direction = 0, rotation_direction = -1, dead = false },
			{ x = 5, y = 1, direction = 0, rotation_direction = -1, dead = false },
			{ x = 17, y = 5, direction = 3, rotation_direction = -1, dead = false },
			{ x = 15, y = 5, direction = 3, rotation_direction = -1, dead = false },
			{ x = 13, y = 10, direction = 2, rotation_direction = -1, dead = false },
			{ x = 13, y = 12, direction = 2, rotation_direction = -1, dead = false },
			{ x = 3, y = 8, direction = 1, rotation_direction = -1, dead = false },
			{ x = 1, y = 8, direction = 1, rotation_direction = -1, dead = false },
		},
		moves = 40
	},

	{
		level_data =
			"#########################"..
			"#......#...#........^..!#"..
			"#......#.#.#.#.#........#"..
			"#......#.#.#.#.#........#"..
			"#!.............#!......!#"..
			"####.####################"..
			"#.....#!......#....!#!.!#"..
			"#.......xxxxx.#.^^^.#.^.#"..
			"#.....#......!#.^^^.#.^.#"..
			"####.##########.^^^.#.^.#"..
			"#......#.....!#.^^^...^.#"..
			"#......#......#!....#..!#"..
			"#......#!.....#######.###"..
			"######.######.#........!#"..
			"#..!#......#..#.xxxxxxx.#"..
			"#^^.#......#..#.xxxxxxx.#"..
			"#^^.#......#..#.xxxxxxx.#"..
			"#^^.#.........#.xxxxxxx.#"..
			"#!.........#...........!#"..
			"#########################"
		,
		width = 25,
		height = 20,
		startx = 3,
		starty =  3,
		enemy_start_positions = {
			{ x = 9, y = 11, direction = 3, rotation_direction = 1, dead = false },
			{ x = 2, y = 15, direction = 3, rotation_direction = 1, dead = false },
			{ x = 16, y = 7, direction = 0, rotation_direction = -1, dead = false },
			{ x = 16, y = 14, direction = 0, rotation_direction = -1, dead = false },
			{ x = 8, y = 9, direction = 0, rotation_direction = 1, dead = false },
			{ x = 22, y = 12, direction = 0, rotation_direction = 1, dead = false },
			{ x = 2, y = 9, direction = 0, rotation_direction = 1, dead = false },
			{ x = 2, y = 11, direction = 0, rotation_direction = -1, dead = false },
			{ x = 24, y = 5, direction = 1, rotation_direction = 1, dead = false },
			{ x = 9, y = 2, direction = 0, rotation_direction = -1, dead = false },
			{ x = 13, y = 5, direction = 0, rotation_direction = 1, dead = false },
		},
		moves = 56
	}
}

function levels.get_tile(level_num, x, y)
	if y <= 0 or y > levels.levels[level_num].height or x <= 0 or x > levels.levels[level_num].width then
		return 'x'	
	end

	local index = (y - 1) * levels.levels[level_num].width + x
	return string.sub(levels.levels[level_num].level_data, index, index)
end

return levels
