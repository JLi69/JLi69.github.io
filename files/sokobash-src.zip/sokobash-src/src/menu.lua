local love = require('love')
local menu = {}

menu.CREDITS = [[Programming: Nullptr Error
Made with LÖVE (https://love2d.org/)

Assets used:
8 Bit Operator Font (Downloaded from: https://www.1001freefonts.com/8-bit-operator.font)

impactsplat01.mp3.flac (by qubodup, downloaded from https://opengameart.org/content/8-wet-squish-slurp-impacts)

mouseclick.wav (by LFA, downloaded from https://opengameart.org/content/mouse-click)

66779__kevinkace__crate-break-3.wav (by kevinkace, downloaded from https://freesound.org/people/kevinkace/sounds/66779/)
]]

menu.INTRO_SCREEN = 0
menu.MAIN_MENU_SCREEN = 1
menu.CREDITS_SCREEN = 2
menu.LEVEL_SELECT = 3
menu.GAME_SCREEN = 4

menu.current_intro_text = 1
menu.intro_text = {
	[[You have had it with these humans 
	thinking they can just push you around!]],

	[[Just because you are a box in a Sokoban
	game doesn't justify it!!!]],

	[[It's time to push back...]]
}

function menu.create_button(buttonx, buttony, buttontext, font, col_normal, col_hovered)
	local button = {
		x = buttonx,
		y = buttony,
		rawtext =  buttontext,
		text = love.graphics.newText(font, { buttontext }),
		color_normal = col_normal,
		color_hovered = col_hovered
	}
	return button
end

function menu.mouse_hovering_button(button, mousex, mousey)
	return button.x - button.text:getWidth() / 2 <= mousex and
		   button.x + button.text:getWidth() / 2 >= mousex and
		   button.y - button.text:getHeight() / 2 <= mousey and
		   button.y + button.text:getHeight() / 2 >= mousey
end

function menu.draw_button(button, mousex, mousey)	
	if menu.mouse_hovering_button(button, mousex, mousey) then		
		love.graphics.setColor(button.color_hovered)
	else	
		love.graphics.setColor(button.color_normal)	
	end

	love.graphics.draw(
		button.text, 
		math.floor(button.x - button.text:getWidth() / 2), 
		math.floor(button.y - button.text:getHeight() / 2)
	)
end

return menu
