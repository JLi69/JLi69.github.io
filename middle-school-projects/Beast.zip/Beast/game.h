#include "gamegraphics.h"
#include <list>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#pragma once
using namespace std;

class Player {
public:
	bool dead = false;
	bool win = false;
	int x;
	int y;
};

class Block {
public:
	int x;
	int y;

	void move(int direction, char axis, list<Block> board, Player player) {
		if (axis == 'x') {
			x += direction;
		}
		else if (axis == 'y') {
			y += direction;
		}
		rect(x + 1, y + 1, 28, 28, RGB(0, 255, 0));
	}
};

class Beast {
public:
	bool dead = false;
	int x;
	int y;
	int delay = 1;
	//Update the beast
	void update(list<Block> blocks, Player player, list<Beast> enemies) {
		//Move the enemies
		if (delay % 28 == 0 && !dead) {
			int minDistanceToPlayer = sqrt(pow(x - player.x, 2) + pow(y - player.y, 2))+30;
			int nextX=x;
			int nextY=y;
			for (int i = y - 30; i <= y + 30; i+=30) {
				for (int j = x - 30; j <= x + 30; j+=30) {
					if (j == x && i == y) {
						continue;
					}
					bool valid = true;
					
					for (list<Block>::iterator it = blocks.begin(); it != blocks.end(); it++) {
						Block b = *it;

						if (b.x == j-15 && b.y == i-15) {
							valid = false;
							break;
						}
					}

					for (list<Beast>::iterator it = enemies.begin(); it != enemies.end(); it++) {
						Beast b = *it;

						if (b.x == j && b.y == i) {
							valid = false;
							break;
						}
					}
					
					if (sqrt(pow(j - player.x, 2) + pow(i - player.y, 2)) <= minDistanceToPlayer && valid) {
						nextX = j;
						nextY = i;
						minDistanceToPlayer = sqrt(pow(j - player.x, 2) + pow(i - player.y, 2));
					}
				}
			}
			if (nextX == x && nextY == y) {
				return;
			}
			circle(x, y, 15, RGB(0, 0, 0));
			x = nextX;
			y = nextY;
			circle(x, y, 15, RGB(255, 0, 0));

			delay = 1;
		}
		delay++;
	}
	//Constructor
	Beast(int xcor, int ycor) {
		x = xcor;
		y = ycor;
	}
};

class Game {
public:
	list<Block> board;
	list<Beast> beasts;
	Player player = Player();
	//Drawing functions
	void drawBoard() {
		//Draw the board
		for (list<Block>::iterator i = board.begin(); i != board.end(); i++) {
			Block block = *i;
			rect(block.x+1, block.y+1, 28, 28, RGB(0, 255, 0));
		}
		//Draw the beasts
		for (list<Beast>::iterator i = beasts.begin(); i != beasts.end(); i++) {
			Beast beast = *i;
			circle(beast.x, beast.y, 15, RGB(255, 0, 0));
		}
		//Draw the player
		circle(player.x, player.y, 15, RGB(0, 162, 255));
	}
	void draw() {
		
	}
	//Update the screen
	void update() {
		bool playerwin = true;
		//Update the beasts
		for (list<Beast>::iterator i = beasts.begin(); i != beasts.end(); i++) {
			Beast b = *i;
			//Check if the beast in inside a block
			for (list<Block>::iterator i2 = board.begin(); i2 != board.end(); i2++) {
				Block block = *i2;
				if (b.x - 15 == block.x && b.y - 15 == block.y && !b.dead) {
					rect(block.x, block.y, 30, 30, RGB(0, 0, 0));
					rect(block.x+1, block.y+1, 28, 28, RGB(0, 255, 0));
					b.dead = true;
				}
			}
			b.update(board, player, beasts);
			//Check if the player died
			if (player.x == b.x && player.y == b.y && b.dead == false) {
				player.dead = true;
			}
			//Check if the player won
			if (b.dead == false) {
				playerwin = false;
			}
			*i = b;
		}
		if (playerwin) {
			player.win = true;
		}
		//Get key input and update the player and the player's environment
		if (GetAsyncKeyState(VK_UP)) {
			if (player.y > 75) {
				circle(player.x, player.y - 30, 15, RGB(0, 162, 255));
				rect(player.x - 15, player.y - 15, 30, 30, RGB(0, 0, 0));
				player.y -= 30;
			}
			//Check if the player collided with any blocks
			for (list<Block>::iterator i = board.begin(); i != board.end(); i++) {
				Block b = *i;
				if (player.x - 15 == b.x && player.y - 15 == b.y) {
					if (player.x > 30 && player.x < 915 && player.y > 30 && player.y < 420) {
						rect(b.x + 1, b.y + 1, 28, 28, RGB(0, 0, 0));
						circle(player.x, player.y, 15, RGB(0, 162, 255));
						
						b.move(-30, 'y', board, player);

						*i = b;
					}
				}
			}
		}
		else if (GetAsyncKeyState(VK_DOWN)) {
			if (player.y <= 390) {
				circle(player.x, player.y + 30, 15, RGB(0, 162, 255));
				rect(player.x - 15, player.y - 15, 30, 30, RGB(0, 0, 0));
				player.y += 30;
			}
			//Check if the player collided with any blocks
			for (list<Block>::iterator i = board.begin(); i != board.end(); i++) {
				Block b = *i;
				if (player.x - 15 == b.x && player.y - 15 == b.y) {
					if (player.x > 30 && player.x < 915 && player.y > 30 && player.y < 420) {
						rect(b.x + 1, b.y + 1, 28, 28, RGB(0, 0, 0));
						circle(player.x, player.y, 15, RGB(0, 162, 255));
						
						b.move(30, 'y', board, player);

						*i = b;
					}
				}
			}
		}
		else if (GetAsyncKeyState(VK_RIGHT)) {
			if (player.x < 885) {
				circle(player.x + 30, player.y, 15, RGB(0, 162, 255));
				rect(player.x - 15, player.y - 15, 30, 30, RGB(0, 0, 0));
				player.x += 30;
			}
			//Check if the player collided with any blocks
			for (list<Block>::iterator i = board.begin(); i != board.end(); i++) {
				Block b = *i;
				if (player.x - 15 == b.x && player.y - 15 == b.y) {
					if (player.x > 30 && player.x < 915 && player.y > 30 && player.y < 420) {
						rect(b.x + 1, b.y + 1, 28, 28, RGB(0, 0, 0));
						circle(player.x, player.y, 15, RGB(0, 162, 255));
						
						b.move(30, 'x', board, player);

						*i = b;
					}
				}
			}
		}
		else if (GetAsyncKeyState(VK_LEFT)) {
			if (player.x > 75) {
				circle(player.x - 30, player.y, 15, RGB(0, 162, 255));
				rect(player.x - 15, player.y - 15, 30, 30, RGB(0, 0, 0));
				player.x -= 30;
			}
			//Check if the player collided with any blocks
			for (list<Block>::iterator i = board.begin(); i != board.end(); i++) {
				Block b = *i;
				//Push the blocks
				if (player.x - 15 == b.x && player.y - 15 == b.y) {
					if (player.x > 30 && player.x < 915 && player.y > 30 && player.y < 420) {
						rect(b.x + 1, b.y + 1, 28, 28, RGB(0, 0, 0));
						circle(player.x, player.y, 15, RGB(0, 162, 255));
						
						b.move(-30, 'x', board, player);

						*i = b;
					}
				}
			}
		}

		Sleep(3);
	}

	Game(int width, int height, int seed) {
		//Keep track of the number of beasts spawned
		int beastsSpawned = 0;
		//Set up the game board
		srand(seed);
		for (int i = 0; i < height; i++) {
			for (int j = 0; j < width; j++) {
				bool validBeastLocation = true;
				//Spawn the player
				if (i == 1 && j == 1) {
					player.x = 75;
					player.y = 75;
					validBeastLocation = false;
				}
				//Spawn blocks in the map
				else if (rand() % 3 == 0) {
					Block b = Block();
					b.x = j * 30 + 30;
					b.y = i * 30 + 30;
					board.push_back(b);
					validBeastLocation = false;
				}
				//Walls of the map
				else if (j == 0 || j == width - 1 || i == 0 || i == height - 1) {
					Block b = Block();
					b.x = j * 30 + 30;
					b.y = i * 30 + 30;
					board.push_back(b);
					validBeastLocation = false;
				}

				//Check if the location is too close to the player
				if (i - 1 < 5 && j - 1 < 5) {
					validBeastLocation = false;
				}

				//Spawn the beasts
				if (rand() % 15 == 0 && beastsSpawned < 4 && validBeastLocation == true) {
					Beast beast = Beast(j * 30 + 45, i * 30 + 45);
					beasts.push_back(beast);
					beastsSpawned++;
				}
			}
		}
	}
};