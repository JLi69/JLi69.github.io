#include <windows.h>
#include <iostream>
#include <math.h>
#pragma once
//This function will draw rectangle
void rect(int x, int y, int width, int height, COLORREF color) {
	//Get the console handle
	HWND console = GetConsoleWindow();
	HDC dc = GetDC(console);

	//Set the x coordiante
	int xcor = x;

	//Draw the rectangle
	for (int i = 0; i < height; i++) {
		for (int j = 0; j < width; j++) {
			SetPixel(dc, x, y, color);
			x++;
		}
		x = xcor;
		//Move down a row
		y++;
	}
}
//This function will draw a circle
void circle(int x, int y, int r, COLORREF color) {
	//Get the console handle
	HWND console = GetConsoleWindow();
	HDC dc = GetDC(console);

	//Draw the circle
	for (int i = y - r; i <= y + r; i++) {
		for (int j = x - r; j <= x + r; j++) {
			if (sqrt((j - x)*(j - x) + (i - y)*(i - y)) < r-1) {
				SetPixel(dc, j-1, i-1, color);
			}
		}
	}
}
