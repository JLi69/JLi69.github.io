#include <iostream>
#include <time.h>
#include "game.h"
using namespace std;

int level = 0;

//yoinked from stack overflow
void ShowConsoleCursor(bool showFlag){
	HANDLE out = GetStdHandle(STD_OUTPUT_HANDLE);

	CONSOLE_CURSOR_INFO     cursorInfo;

	GetConsoleCursorInfo(out, &cursorInfo);
	cursorInfo.bVisible = showFlag; // set the cursor visibility
	SetConsoleCursorInfo(out, &cursorInfo);
}

void run() {
	//Set the seed for the game map
	Game game = Game(30, 14, time(NULL));
	//Clear the screen
	system("cls");
	cout << "LEVELS CLEARED: " << level;
	//Load the map
	game.drawBoard();
	//Main game loop
	while (!game.player.dead && !game.player.win) {
		game.draw();
		game.update();
	}
	//End the game
	if (game.player.dead) {
		circle(game.player.x, game.player.y, 15, RGB(255, 0, 0));

		//Clear the map in an epic way
		for (int i = 0; i < 14; i++) {
			for (int j = 0; j < 30; j++) {
				rect(j * 30 + 30, i * 30 + 30, 30, 30, RGB(0, 0, 0));
			}
		}
	}
	//If the player beat the level, continue
	else if (game.player.win) {
		level++;
		run();
	}
	//This will just prevent the screen from immediately closing
	while (true) {
		//Don't question the infinite empty loop
	}
}

int main() {
	ShowConsoleCursor(false);
	//yoinked from stack overflow
	//Disable the maximize button
	HWND hwnd = GetConsoleWindow();
	DWORD style = GetWindowLong(hwnd, GWL_STYLE);
	style &= ~WS_MAXIMIZEBOX;
	SetWindowLong(hwnd, GWL_STYLE, style);
	SetWindowPos(hwnd, NULL, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE | SWP_FRAMECHANGED);
	//Run the game
	run();
	return 0;
}