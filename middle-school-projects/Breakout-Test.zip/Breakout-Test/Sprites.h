#include <windows.h>
#include <list>
#include <math.h>
#pragma once

static bool start = false;

class Sprite {
public:
	RECT box;
	COLORREF color;
	int x, y, width, height, speedX, speedY;
	//Draw the sprite
	void draw(HDC hdc) {
		//Update the 'hitbox'
		box.left = x + 1;
		box.right = x + width - 1;
		box.top = y + 1;
		box.bottom = y + height - 1;
		//Draw the rectangle that would represent the sprite
		HBRUSH brush = CreateSolidBrush(color);
		FillRect(hdc, &box, brush);
		//Delete the brush to free up resources
		DeleteObject(brush);
	}
	//Update the sprite
	void update() {
		if (start) {
			x += speedX;
			y += speedY;
		}
	}
};

class Paddle : public Sprite {
private:
	const int speed = 4;
public:
	//Constructor
	Paddle(int X, int Y) {
		color = RGB(0, 0, 255);

		x = X;
		y = Y;

		width = 160;
		height = 24;

		speedX = 0;
		speedY = 0;
	}

	void update() {
		//Start the game if the player hits space
		if (GetAsyncKeyState(VK_SPACE)) {
			start = true;
		}

		//Move the paddle
		if (GetAsyncKeyState(VK_LEFT) && start) {
			speedX = -speed;
		}
		else if (GetAsyncKeyState(VK_RIGHT) && start) {
			speedX = speed;
		}
		else {
			speedX = 0;
		}

		x += speedX;
	}
};

class Block : public Sprite {
public:
	//Constructor
	Block(int X, int Y) {
		color = RGB(0, 0, 255);

		speedX = 0;
		speedY = 0;

		x = X;
		y = Y;

		width = 80;
		height = 40;
	}
};

class Ball : public Sprite {
private:
	const int speed = 2;
public:
	//Constructor
	Ball(int X, int Y) {
		x = X;
		y = Y;

		speedX = speed;
		speedY = speed;

		width = 24;
		height = 24;

		color = RGB(0, 0, 255);
	}

	void bounce(std::list<Block> blocks, Paddle player) {
		//Bounce the ball
		if (x < 0 || x > 805 - width) {
			speedX *= -1;
		}
		if(y < 0) {
			speedY *= -1;
		}

		if (x > player.x - width && x < player.x + player.width && y > player.y - height && y < player.y + player.height) {
			y = player.y - height;

			speedY *= -1;

			update();
		}
	}
};