#include <windows.h>
#include "minesweeperlogic.h"
#include <stdlib.h>
#include <time.h>
#include <math.h>
#pragma once

class Game {
private:
	TileMap map;
	bool leftclicked = false;
	bool gameOver = false;
	//The number of mines on the board
	int numberOfMines = 40;
public:
	//Draw
	void draw(HDC hdc, HWND hWnd) {
		map.drawmap(hdc);

		//Draw where the mouse would click
		POINT mousepos;
		GetCursorPos(&mousepos);
		ScreenToClient(hWnd, &mousepos);

		int X = floor(mousepos.x / tilesize);
		int Y = floor(mousepos.y / tilesize);

		//Fill a cyan rectangle
		RECT r = { X*(tilesize - 1) + 1, Y*(tilesize - 1) + 1, X*(tilesize - 1) + tilesize - 1, Y*(tilesize - 1) + tilesize - 1 };
		HBRUSH brush = CreateSolidBrush(RGB(0, 255, 255));
		FillRect(hdc, &r, brush);
		//Clear up the GDI object
		DeleteObject(brush);
	}

	//Handle a left click
	void handleleftclick(HWND hWnd) {
		if (gameOver) {
			return;
		}

		POINT mousepos;
		GetCursorPos(&mousepos);
		ScreenToClient(hWnd, &mousepos);

		int X = floor(mousepos.x / tilesize);
		int Y = floor(mousepos.y / tilesize);

		try {
			if (map.tilemap.at(Y).at(X).revealed) {
				return;
			}
		}
		catch (std::out_of_range) {
			return;
		}

		map.tilemap.at(Y).at(X).revealed = true;
		map.tilemap.at(Y).at(X).flagged = false;

		//Do this only when the player first clicks
		if (!leftclicked) {
			//Load the mines
			for (int i = 0; i < numberOfMines; i++) {
				while (true) {

					int tempX = rand() % map.tilemap.at(0).size();
					int tempY = rand() % map.tilemap.size();

					bool adjacentToRevealed = false;
					for (int rowBack = -1; rowBack <= 1; rowBack++) {
						for (int columnBack = -1; columnBack <= 1; columnBack++) {
							try {
								if (map.tilemap.at(tempY+rowBack).at(tempX+columnBack).revealed) {
									adjacentToRevealed = true;
									break;
								}
							}
							catch (std::out_of_range) {
								continue;
							}
						}
					}
					if (adjacentToRevealed) {
						continue;
					}

					if (!map.tilemap.at(tempY).at(tempX).revealed && !map.tilemap.at(tempY).at(tempX).mined) {
						map.tilemap.at(tempY).at(tempX).mined = true;
						break;
					}
				}
			}

			//Calculate the neighbors
			for (int i = 0; i < map.tilemap.size(); i++) {
				for (int j = 0; j < map.tilemap.at(i).size(); j++) {
					//Store the number of neighbors
					int numOfNeighbors = 0;
					//Iterate through the neighbors
					for (int rowBack = -1; rowBack <= 1; rowBack++) {
						for (int columnBack = -1; columnBack <= 1; columnBack++) {
							if (rowBack == 0 && columnBack == 0) {
								continue;
							}

							try {
								if (map.tilemap.at(i + rowBack).at(j + columnBack).mined) {
									numOfNeighbors++;
								}
							}
							catch (std::out_of_range) {
								continue;
							}
						}
					}
					map.tilemap.at(i).at(j).neighbors = numOfNeighbors;
				}
			}
		}

		//Reveal any neighbors that have no neighboring mines
		map.tilemap.at(Y).at(X).revealneighbors(X, Y, map.tilemap, 144);

		if (map.tilemap.at(Y).at(X).mined) {
			MessageBox(hWnd, "You Lose!", "BOOM!", NULL);

			for (int i = 0; i < map.tilemap.size(); i++) {
				for (int j = 0; j < map.tilemap.at(i).size(); j++) {
					map.tilemap.at(i).at(j).revealed = true;
				}
			}

			gameOver = true;
		}

		leftclicked = true;
	}

	//Handle a right click
	void handlerightclick(HWND hWnd) {
		if (gameOver) {
			return;
		}

		POINT mousepos;
		GetCursorPos(&mousepos);
		ScreenToClient(hWnd, &mousepos);

		int X = floor(mousepos.x / tilesize);
		int Y = floor(mousepos.y / tilesize);

		try {
			if (map.tilemap.at(Y).at(X).revealed) {
				return;
			}
			else {
				map.tilemap.at(Y).at(X).flagged = !map.tilemap.at(Y).at(X).flagged;
			}
		}
		catch (std::out_of_range) {
			return;
		}

		//Check if the player won
		int correct = 0;
		for (int i = 0; i < map.tilemap.size(); i++) {
			for (int j = 0; j < map.tilemap.at(i).size(); j++) {
				if (map.tilemap.at(i).at(j).flagged && map.tilemap.at(i).at(j).mined) {
					correct++;
				}
			}
		}
		if (correct == numberOfMines) {
			MessageBox(hWnd, "You Win!", "", NULL);
			gameOver = true;
		}
	}

	//Constructor
	Game() {
		srand(time(NULL));
		map.setup(22, 15);
	}
};