#include <vector>
#include <windows.h>
#include <sstream>
#pragma once

const int tilesize = 35;

struct Tile {
	//Store whether the tile has a mine
	bool mined = false;
	//Store whether the tile was flagged by player
	bool flagged = false;
	//Store whether the tile was revealed
	bool revealed = false;
	//Store the number of adjacent cells that are mines
	int neighbors = 0;

	void revealneighbors(int posX, int posY, std::vector<std::vector<Tile>> &tilemap, int depth) {
		//Prevent stack overflow error
		if (depth <= 0) {
			return;
		}

		//If there are mines around, don't reveal neighbors
		if (tilemap.at(posY).at(posX).neighbors > 0) {
			return;
		}
		
		//Iterate though the neighbors and use recursion
		for (int rowBack = -1; rowBack <= 1; rowBack++) {
			for (int columnBack = -1; columnBack <= 1; columnBack++) {
				/*if (abs(rowBack) == abs(columnBack)) {
					continue;
				}*/

				if (rowBack == 0 && columnBack == 0) {
					continue;
				}

				try {
					if (tilemap.at(posY + rowBack).at(posX + columnBack).mined 
						|| tilemap.at(posY + rowBack).at(posX + columnBack).flagged
						|| tilemap.at(posY + rowBack).at(posX + columnBack).revealed) {
						continue;
					}
					else if (tilemap.at(posY + rowBack).at(posX + columnBack).neighbors > 0) {
						tilemap.at(posY + rowBack).at(posX + columnBack).revealed = true;
						continue;
					}
					else {
						tilemap.at(posY + rowBack).at(posX + columnBack).revealed = true;
						tilemap.at(posY + rowBack).at(posX + columnBack).revealneighbors(posX + columnBack, posY + rowBack, tilemap, depth-1);
					}
				}
				catch (std::out_of_range) {
					continue;
				}
			}
		}
	}
};

struct TileMap {
	//Grid of tiles
	std::vector<std::vector<Tile>> tilemap;

	void setup(int WIDTH, int HEIGHT) {
		//Clear the tilemap
		tilemap.clear();

		for (int i = 0; i < HEIGHT; i++) {
			//The row to store current tiles
			std::vector<Tile> temprow;
			for (int j = 0; j < WIDTH; j++) {
				//Create a tile
				Tile temptile;
				//Add the tile to the row
				temprow.push_back(temptile);
			}
			//Add the row to the tile map
			tilemap.push_back(temprow);
		}
	}

	void drawmap(HDC hdc) {
		//Draw the tiles
		for (int i = 0; i < tilemap.size(); i++) {
			for (int j = 0; j < tilemap.at(i).size(); j++) {
				//Draw outline
				Rectangle(hdc, j*(tilesize - 1), i*(tilesize - 1), j*(tilesize - 1) + tilesize, i*(tilesize - 1) + tilesize);
				if (tilemap.at(i).at(j).revealed) {
					if (!tilemap.at(i).at(j).mined) {
						//Fill a green rectangle at a revealed spot that isn't mined
						RECT r = { j*(tilesize - 1) + 1, i*(tilesize - 1) + 1, j*(tilesize - 1) + tilesize - 1, i*(tilesize - 1) + tilesize - 1 };
						HBRUSH brush = CreateSolidBrush(RGB(0, 255, 0));
						FillRect(hdc, &r, brush);
						//Clear up the GDI object
						DeleteObject(brush);
					}
					else {
						//Fill a red rectangle at a revealed spot that is mined
						RECT r = { j*(tilesize - 1) + 1, i*(tilesize - 1) + 1, j*(tilesize - 1) + tilesize - 1, i*(tilesize - 1) + tilesize - 1 };
						HBRUSH brush = CreateSolidBrush(RGB(255, 0, 0));
						FillRect(hdc, &r, brush);
						//Clear up the GDI object
						DeleteObject(brush);
						continue;
					}

					//If there are mines nearby, show the player the number of mines
					if (tilemap.at(i).at(j).neighbors > 0) {
						//Set the background color to be green
						SetBkColor(hdc, RGB(0, 255, 0));
						//String stream that is storing the text
						std::stringstream text;
						//Add the number of neighbors
						text << tilemap.at(i).at(j).neighbors;
						//Convert stringstream into a string
						std::string stringtext = text.str();
						//Draw the text
						TextOut(hdc, j*(tilesize - 1) + tilesize / 2 - 4, i*(tilesize - 1) + tilesize / 2 - 8,
							stringtext.c_str(), stringtext.length());
					}
				}

				if (tilemap.at(i).at(j).flagged) {
					//Draw a yellow rectangle if it's flagged
					RECT r = { j*(tilesize - 1) + 1, i*(tilesize - 1) + 1, j*(tilesize - 1) + tilesize - 1, i*(tilesize - 1) + tilesize - 1 };
					HBRUSH brush = CreateSolidBrush(RGB(255, 255, 0));
					FillRect(hdc, &r, brush);
					//Clear up the GDI object
					DeleteObject(brush);
				}
			}
		}
	}
};
