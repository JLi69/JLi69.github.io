#include <windows.h>
#include <stdlib.h>
#include <string.h>
#include <tchar.h>
#include <list>

#include "game.h"
using namespace std;

//Global variables
static TCHAR szWindowClass[] = _T("DesktopApp");

//Screen title
static TCHAR szTitle[] = _T("PLATFORMER");

HINSTANCE hInst;

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);

Game game = Game();

//Setup function
void setup() {

}

//paint function
static void paint(HWND hWnd, LPPAINTSTRUCT lpPS) {
	RECT rc;
	HDC hdcMem;
	HBITMAP hbmMem, hbmOld;
	HBRUSH hbrBkGnd;
	//Get the size of the client rectangle
	GetClientRect(hWnd, &rc);
	//Create a compatible dc
	hdcMem = CreateCompatibleDC(lpPS->hdc);
	//Create a bitmap big enough for our client rectangle
	hbmMem = CreateCompatibleBitmap(lpPS->hdc, rc.right - rc.left, rc.bottom - rc.top);
	//Select the bitmap into the off-screen DC
	hbmOld = (HBITMAP)SelectObject(hdcMem, hbmMem);
	//Erase the background
	hbrBkGnd = CreateSolidBrush(GetSysColor(COLOR_WINDOW));
	FillRect(hdcMem, &rc, hbrBkGnd);
	DeleteObject(hbrBkGnd);

	//Render the image into the offscreen DC
	//Add code here to draw graphics using hdc
	game.drawworld(hdcMem);

	//Blt the changes to the screen DC
	BitBlt(lpPS->hdc, rc.left, rc.top, rc.right - rc.left, rc.bottom - rc.top, hdcMem, 0, 0, SRCCOPY);

	//Done withe the off-screen bitmap and DC
	SelectObject(hdcMem, hbmOld);
	DeleteObject(hbmMem);
	DeleteDC(hdcMem);
}

int CALLBACK WinMain(
	_In_ HINSTANCE hInstance,
	_In_opt_ HINSTANCE hPrevInstance,
	_In_ LPSTR     lpCmdLine,
	_In_ int       nCmdShow
) {
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX);
	wcex.style = CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc = WndProc;
	wcex.cbClsExtra = 0;
	wcex.cbWndExtra = 0;
	wcex.hInstance = hInstance;
	wcex.hIcon = LoadIcon(hInstance, IDI_APPLICATION);
	wcex.hCursor = LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
	wcex.lpszMenuName = NULL;
	wcex.lpszClassName = szWindowClass;
	wcex.hIconSm = LoadIcon(wcex.hInstance, IDI_APPLICATION);

	//If there's an error alert the user
	if (!RegisterClassEx(&wcex)) {
		MessageBox(NULL, _T("Call to RegisterClassEx failed!"), _T(""), NULL);

		return 1;
	}

	hInst = hInstance;

	HWND hWnd = CreateWindow(szWindowClass, szTitle,
		WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, 795, 600, NULL, NULL, hInstance, NULL);
	//If the computer failed to create a window, alert the user
	if (!hWnd) {
		MessageBox(NULL, _T("Call to CreateWindow failed!"), _T(""), NULL);

		return 1;
	}

	//Make the window visible
	ShowWindow(hWnd, nCmdShow);
	//Update the window
	UpdateWindow(hWnd);

	//Set a timer (Default set to 15 milliseconds) (Default ID is 1)
	SetTimer(hWnd, 1, 15, (TIMERPROC)NULL);

	//Run setup function
	setup();

	//Main message loop:
	MSG msg;
	while (GetMessage(&msg, NULL, 0, 0)) {
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	return (int)msg.wParam;
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
	PAINTSTRUCT ps;
	HDC hdc;

	switch (message) {
	case WM_TIMER:
		switch (wParam) {
		case 1:
			//Update the window
			RedrawWindow(hWnd, nullptr, nullptr, RDW_ERASE | RDW_INVALIDATE);
			//Update the world
			game.updateworld();
		}
		break;
	case WM_ERASEBKGND:
		return (LRESULT)1;
	case WM_PAINT:
		hdc = BeginPaint(hWnd, &ps);
		paint(hWnd, &ps);
		EndPaint(hWnd, &ps);
		break;
	case WM_DESTROY:
		KillTimer(hWnd, 1);
		PostQuitMessage(0);
		break;
	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
		break;
	}

	return 0;
}