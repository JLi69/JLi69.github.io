#include "sprites.h"
#include <list>
#include <fstream>
#include <string>
#include <vector>
#pragma once

class Game {
private:
	//Background
	const COLORREF bkgnd = RGB(66, 135, 245);
	//Gameobjects
	//Player object
	Player player = Player(0.0f, 0.0f, 40.0f, 40.0f);
	//This list will store the blocks
	std::list<Block> blocks;

	//Level file names
	std::vector<std::string> levelfilenames = { "level1.txt", "level2.txt", "level3.txt", "level4.txt", "level5.txt" };
	int currentlevel = 1;

	//End of level
	float endOfLevelX = 800.0f - 39.0f;

	//Keep track if the player won
	bool win = false;
public:
	//Load a level from a file
	void loadLevel(std::string filename) {
		//Reset the player
		player.x = 0.0f;
		player.y = 0.0f;
		//Clear the map
		blocks.clear();
		//Keep track of the y coordinate
		float y = 0.0f;

		//The row of the file
		std::string row;
		//File object
		std::ifstream levelmap(filename);
		//Iterate through the file
		while (getline(levelmap, row)) {
			for (int x = 0; x < row.length(); x++) {
				//Empty air
				if (row[x] == '.') {
					continue;
				}
				//Block
				else if (row[x] == '#') {
					Block b = Block(x*39.0f, y*39.0f);
					blocks.push_back(b);

					if (39.0f * x > endOfLevelX) {
						endOfLevelX = 39.0f * x;
					}
				}
				//player starting position
				else if (row[x] == 'p') {
					player.x = x * 39.0f;
					player.y = y * 39.0f;
				}
			}
			y++;
		}
		//Close the file
		levelmap.close();
	}

	//Draw items in the game world
	void drawworld(HDC hdc) {
		if (win) {
			int size = 16;
			int xcoordinate = 112;
			int ycoordinate = 144;

			char text[6][34] = {
			"#..#.#####.#..#....#...#.#.#....#",
			"#..#.#...#.#..#....#...#.#.##...#",
			"####.#...#.#..#....#...#.#.#.#..#",
			"...#.#...#.#..#....#.#.#.#.#..#.#",
			"...#.#...#.#..#....#.#.#.#.#...##",
			"####.#####.####....#####.#.#....#",
			};

			for (int i = 0; i < 6; i++) {
				for (int j = 0; j < 34; j++) {
					if (text[i][j] == '#') {

						RECT r = { j * size + xcoordinate,
							i * size + ycoordinate,
							j * size + size + xcoordinate,
							i * size + size + ycoordinate };

						HBRUSH brush = CreateSolidBrush(RGB(0, 0, 0));
						FillRect(hdc, &r, brush);
						DeleteObject(brush);
					}
				}
			}

			return;
		}

		//Draw the background
		RECT r = { 0, 0, 3000, 3000 };
		HBRUSH brush = CreateSolidBrush(bkgnd);
		FillRect(hdc, &r, brush);
		DeleteObject(brush);
		//Draw the player
		player.draw(hdc);

		//Draw the blocks
		for (std::list<Block>::iterator it = blocks.begin(); it != blocks.end(); it++) {
			Block tempBlock = *it;

			tempBlock.draw(hdc);
		}
	}

	//Update the game world
	void updateworld() {
		player.update();
		player.handleCollision(blocks, endOfLevelX);
		//If the player falls off the screen, reset the level
		if (player.y >= player.playerfloor()) {
			try {
				loadLevel(levelfilenames.at(currentlevel - 1));
			}
			catch (std::out_of_range) {
				loadLevel(levelfilenames.at(levelfilenames.size() - 1));
			}
			player.killvelocity();
			return;
		}

		if (player.x >= endOfLevelX) {
			currentlevel++;
			try {
				loadLevel(levelfilenames.at(currentlevel - 1));
			}
			catch (std::out_of_range) {
				//The player beat all the levels
				win = true;
			}
		}
	}

	//Constructor
	Game() {
		//Load level 1
		loadLevel(levelfilenames.at(currentlevel-1));
	}
};
