#include <windows.h>
#include <list>
#pragma once

//Generic 2d sprite
class Sprite {
public:
	float x, y, width, height;
	COLORREF color;

	virtual void draw(HDC hdc) {
		//Outline
		Rectangle(hdc, x, y, x + width, y + height);
		//The filled interior
		RECT box = { x+1, y+1, x+width-1, y+height-1 };
		HBRUSH brush = CreateSolidBrush(color);
		FillRect(hdc, &box, brush);
		//Delete GDI object
		DeleteObject(brush);
	}

	virtual void update() {}
};

class Block : public Sprite {
public:
	//Constructor
	Block(float X, float Y) {
		x = X;
		y = Y;
		width = 40.0f;
		height = 40.0f;
		color = RGB(0, 255, 0);
	}
};

//Player sprite
class Player : public Sprite {
private:
	bool grounded = false;
	//The "jump force" of the player
	const float upForce = 11.0f;
	//The force of gravity
	float gravityForce = 0.5f;
	//Velocity in y direction
	float velY = 0.0f;
	//Velocity in the x direction
	float velX = 0.0f;

	//Y coordinate where the player stops falling
	float worldfloor = 640.0f;
public:
	void handleCollision(std::list<Block> &world, float &endOfLevelX) {
		bool collisionDetected = false;
		for (std::list<Block>::iterator it = world.begin(); it != world.end(); it++) {
			Block tempBlock = *it;
			//If the block is off the screen, don't bother checking for collision
			if (tempBlock.x < -tempBlock.width || tempBlock.x > 800.0f || tempBlock.y < 0.0f || tempBlock.y > 800.0f) {
				continue;
			}

			//Check for collision
			if (x > tempBlock.x - width && x < tempBlock.x + tempBlock.width && y > tempBlock.y - height && y < tempBlock.y + tempBlock.height) {
				if (y <= tempBlock.y - tempBlock.height / 2) {
					y = tempBlock.y - height;
					velY = 0.0f;
					grounded = true;
				}
				else if (y > tempBlock.y + tempBlock.height / 2 && x > tempBlock.x - width && x < tempBlock.x + tempBlock.width && velY > 0.0f) {
					y = tempBlock.y + tempBlock.height + 2;
					velY = -gravityForce;
					grounded = false;
				}
				else if (x < tempBlock.x && y > tempBlock.y - height && y < tempBlock.y + tempBlock.height) {
					velX = 0.0f;
					if (y < tempBlock.y - height) {
						velY = 0.0f;
					}
					x = tempBlock.x - width;
				}
				else if (x > tempBlock.x && y > tempBlock.y - height && y < tempBlock.y + tempBlock.height) {
					velX = 0.0f;
					if (y <= tempBlock.y - height) {
						velY = 0.0f;
					}
					x = tempBlock.x + tempBlock.width;
				}
				
				collisionDetected = true;
			}
		}

		if (!collisionDetected) {
			grounded = false;
		}

		if (x < 0.0f) {
			x = 0.0f;
		}
		//Side scrolling
		if (x > 500.0f && endOfLevelX >= 800.0f) {
			for (std::list<Block>::iterator it = world.begin(); it != world.end(); it++) {
				Block tempBlock = *it;
				tempBlock.x -= (x - 500.0f);///velX;
				*it = tempBlock;
			}
			endOfLevelX -= (x - 500.0f);///velX;

			x = 500.0f;
		}
	}
	//Returns the value of the world floor
	float playerfloor() {
		return worldfloor - height;
	}
	//Sets the player's velocity to be 0
	void killvelocity() {
		velX = 0.0f;
		velY = 0.0f;
	}

	void update() override {
		if (GetAsyncKeyState(VK_UP) && grounded) {
			//Have the player jump
			velY = upForce;
			grounded = false;
		}
		else if (GetAsyncKeyState(VK_RIGHT)) {
			velX = 6.0f;
		}
		else if (GetAsyncKeyState(VK_LEFT)) {
			velX = -6.0f;
		}
		else {
			velX = 0.0f;
		}

		if (y >= worldfloor - height) {
			velY = 0.0f;
			velX = 0.0f;
			y = worldfloor - height;
			grounded = true;
		}

		y -= velY;
		if (!grounded) {
			velY -= gravityForce;
		}

		x += velX;
	}

	//Constructor
	Player(float X, float Y, float WIDTH, float HEIGHT) {
		x = X;
		y = Y;
		width = WIDTH;
		height = HEIGHT;

		color = RGB(255, 255, 0);
	}
};
