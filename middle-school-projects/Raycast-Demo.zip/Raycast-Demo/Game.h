#include "raycastlogic.h"
#include <windows.h>
#include <string>

#include <sstream>
#include <chrono>
#pragma once

class Game {
private:
	//How far the player can see
	float renderdistance = 128.0f;
	//FOV of the player
	float FOV = 60.0f;

	//This will store the map
	std::vector<std::vector<int>> map = {
	{ 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 },
	{ 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1 },
	{ 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1 },
	{ 1, 0, 0, 0, 0, 0, 2, 2, 2, 0, 2, 0, 1 },
	{ 1, 0, 0, 0, 0, 0, 2, 0, 0, 0, 2, 0, 1 },
	{ 1, 0, 0, 0, 0, 0, 2, 0, 0, 0, 2, 0, 1 },
	{ 1, 0, 0, 0, 0, 0, 2, 0, 0, 0, 2, 0, 1 },
	{ 1, 0, 4, 0, 4, 0, 2, 0, 0, 0, 2, 0, 1 },
	{ 1, 0, 0, 0, 0, 0, 2, 0, 0, 0, 2, 0, 1 },
	{ 1, 0, 3, 0, 3, 0, 2, 2, 2, 2, 2, 0, 1 },
	{ 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1 },
	{ 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 }
	};

	//This will store the "z-buffer" for the walls
	std::vector<float> zbuffer;

	//Player position
	Vector2D playerpos = { 1.5f, 1.5f };
	//Player rotation
	float rotation = 0.0f;
public:
	//Get player key input
	void getKeyInput() {
		//Rotate with the arrow keys
		if (GetAsyncKeyState(VK_RIGHT)) {
			rotation += 3;
			convertDeg(rotation);
		}
		else if (GetAsyncKeyState(VK_LEFT)) {
			rotation -= 3;
			convertDeg(rotation);
		}

		//Move around with the arrow keys
		if (GetAsyncKeyState(VK_UP)) {
			bool canmove = true;

			//Handle Collision
			RayCastData tempdata = projectRay(map, playerpos, rotation, 2.0f, rotation);
			if (tempdata.dist <= 0.2f && tempdata.dist >= 0.0f) {
				canmove = false;
			}

			if (canmove) {
				playerpos.x += cos(degreesToRadians(rotation))*0.2f;
				playerpos.y += sin(degreesToRadians(rotation))*0.2f;
			}
		}
		else if (GetAsyncKeyState(VK_DOWN)) {
			bool canmove = true;

			//Handle Collision
			float oppositeRotation = rotation + 180.0f;
			RayCastData tempdata = projectRay(map, playerpos, convertDeg(oppositeRotation), 2.0f, rotation);
			if (tempdata.dist <= 0.2f && tempdata.dist >= 0.0f) {
				canmove = false;
			}

			if (canmove) {
				playerpos.x -= cos(degreesToRadians(rotation))*0.2f;
				playerpos.y -= sin(degreesToRadians(rotation))*0.2f;
			}
		}
	}

	//Draw minimap (for debugging)
	void drawMiniMap(HDC hdc) {
		//Draw the map
		for (int i = 0; i < map.size(); i++) {
			for (int j = 0; j < map.at(i).size(); j++) {
				if (map.at(i).at(j) >= 1) {
					Rectangle(hdc, j * 20, i * 20, j * 20 + 20, i * 20 + 20);

					HBRUSH color;
					RayCastData tempdata;
					tempdata.type = map.at(i).at(j);
					color = CreateSolidBrush(tempdata.color());
					RECT r = { j * 20 + 1, i * 20 + 1, j * 20 + 19, i * 20 + 19 };
					FillRect(hdc, &r, color);
					DeleteObject(color);
				}
			}
		}
		//Draw the rays that are being cast by the player (for debugging)
		for (float i = -FOV / 2+rotation; i <= FOV / 2 +rotation; i += 3.0f) {
			float deg = i;
			drawRayHit(hdc, map, playerpos, convertDeg(deg), renderdistance, rotation);
		}
	}

	//Render the world as a 3d image
	void render(HDC hdc, float screenwidth, float screenheight) {
		//Clear the z-buffer
		zbuffer.clear();

		//Frame counter
		std::chrono::time_point<std::chrono::system_clock> start, end;
		//Get the time when the computer starts drawing the frame
		start = std::chrono::system_clock::now();

		/*
			Render the screen
		*/

		//Draw the ground
		HBRUSH brush = CreateSolidBrush(RGB(0, 255, 0));
		RECT ground = { 0, screenheight / 2, screenwidth, screenheight };
		FillRect(hdc, &ground, brush);
		DeleteObject(brush);
		//Draw the sky
		HBRUSH brush2 = CreateSolidBrush(RGB(0, 200, 255));
		RECT sky = { 0, 0, screenwidth, screenheight / 2 };
		FillRect(hdc, &sky, brush2);
		DeleteObject(brush2);

		//Cast the rays
		for (float deg = -FOV/2 + rotation; deg <= FOV/2 + rotation; deg += 1.0f) {
			float deg2 = deg;
			RayCastData data = projectRay(map, playerpos, convertDeg(deg2), renderdistance, rotation);
			//Get the wall's distance
			float dist = data.dist;
			zbuffer.push_back(dist); //Add the distance to the z-buffer
			//If the distance is less than 0, don't do anything
			if (dist <= 0) {
				continue;
			}
			else {
				float rectHeight = screenheight / dist;

				HBRUSH color;

				color = CreateSolidBrush(data.color());

				RECT r = { deg * screenwidth / FOV + FOV/2 * screenwidth / FOV - rotation * screenwidth / FOV,
					screenheight / 2 - rectHeight / 2,
					deg * screenwidth / FOV + screenwidth / FOV + FOV/2 * screenwidth / FOV - rotation * screenwidth / FOV,
					screenheight / 2 + rectHeight / 2 };
				FillRect(hdc, &r, color);

				DeleteObject(color);
			}
		}

		/*
			Render the sprites
		*/
		

		///drawMiniMap(hdc);

		//Get the time when the computer finishes drawing the frame
		end = std::chrono::system_clock::now();
		//Calculate the number of seconds passed
		std::chrono::duration<float> elapsedTime = end - start;
		//Estimate the number of frames that will pass in a second
		float estimatedFramesPerSecond = 1 / elapsedTime.count();
		//Output the estimated number of frames per second
		std::stringstream text;
		text << " " << (int)estimatedFramesPerSecond << " ";
		TextOut(hdc, screenwidth - 55, 10, text.str().c_str(), text.str().length());
	}
};
