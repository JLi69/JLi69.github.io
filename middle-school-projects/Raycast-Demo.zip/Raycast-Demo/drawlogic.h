#include <windows.h>
#pragma once

//Width and height of the screen
const float width = 820;
const float height = 600;

void drawLine(HDC hdc, COLORREF color, float x1, float y1, float x2, float y2) {
	//Make sure you aren't dividing by 0
	if (x2 - x1 != 0) {
		//Calculate the slope of the line
		float slope = (y1 - y2) / (x1 - x2);

		//Draw the line
		if (x1 < x2) {
			for (float i = x1; i < x2; i++) {
				if (i < 0 || i > width) {
					continue;
				}

				SetPixel(hdc, (int)i, (int)(i*slope + y1 - x1 * slope), color);
			}
		}
		else {
			for (float i = x2; i < x1; i++) {
				if (i < 0 || i > width) {
					continue;
				}

				SetPixel(hdc, (int)i, (int)(i*slope + y1 - x1 * slope), color);
			}
		}

		if (y1 < y2) {
			for (float i = y1; i < y2; i++) {
				if (i < 0 || i > height) {
					continue;
				}

				SetPixel(hdc, (int)(i / slope - (y1 - x1 * slope) / slope), (int)i, color);
			}
		}
		else {
			for (float i = y2; i < y1; i++) {
				if (i < 0 || i > height) {
					continue;
				}

				SetPixel(hdc, (int)(i / slope - (y1 - x1 * slope) / slope), (int)i, color);
			}
		}
	}
	else {
		//Draw a vertical line if the slope is undefined
		if (y2 > y1) {
			for (float i = y1; i < y2; i++) {
				if (i < 0 || i > 600) {
					continue;
				}

				SetPixel(hdc, (int)x1, (int)i, color);
			}
		}
		else {
			for (float i = y2; i < y1; i++) {
				if (i < 0 || i > 600) {
					continue;
				}

				SetPixel(hdc, (int)x1, (int)i, color);
			}
		}
	}
}

//Draw an outline of a triangle
void drawTriangle(HDC hdc, float x1, float y1, float x2, float y2, float x3, float y3) {
	drawLine(hdc, RGB(0, 0, 0), x1, y1, x2, y2);
	drawLine(hdc, RGB(0, 0, 0), x1, y1, x3, y3);
	drawLine(hdc, RGB(0, 0, 0), x2, y2, x3, y3);
}

//Fill in a triangle with a flat base at the bottom
void fillFlatBottomTriangle(HDC hdc, COLORREF color, float x1, float y1, float x2, float y2, float x3, float y3) {
	if (y1 == y2 && y2 == y3) {
		return;
	}

	float invslope1 = (x2 - x1) / (y2 - y1);
	float invslope2 = (x3 - x1) / (y3 - y1);

	float curX1 = x1;
	float curX2 = x1;

	for (int i = y1; i <= y2; i++) {
		drawLine(hdc, color, curX1, i, curX2, i);

		curX1 += invslope1;
		curX2 += invslope2;
	}
}
//Fill in a triangle with a flat base at the top
void fillFlatTopTriangle(HDC hdc, COLORREF color, float x1, float y1, float x2, float y2, float x3, float y3) {
	if (y1 == y2 && y2 == y3) {
		return;
	}

	float invslope1 = (x2 - x1) / (y2 - y1);
	float invslope2 = (x3 - x1) / (y3 - y1);

	float curX1 = x1;
	float curX2 = x1;

	for (int i = y1; i >= y2; i--) {
		drawLine(hdc, color, curX1, i, curX2, i);

		curX1 -= invslope1;
		curX2 -= invslope2;
	}
}


//Fill a generic triangle
void fillTriangle(HDC hdc, COLORREF color, float x1, float y1, float x2, float y2, float x3, float y3) {
	float points[3][2] = { { x1, y1 }, { x2, y2 }, { x3, y3 } };
	//Find the highest point and the lowest point
	float highestPoint[2] = { x1, y1 };
	float lowestPoint[2] = { x1, y1 };
	for (int i = 1; i < 3; i++) {
		if (points[i][1] > lowestPoint[1]) {
			lowestPoint[0] = points[i][0];
			lowestPoint[1] = points[i][1];
		}

		if (points[i][1] < highestPoint[1]) {
			highestPoint[0] = points[i][0];
			highestPoint[1] = points[i][1];
		}
	}

	if (highestPoint[1] == lowestPoint[1]) {
		return;
	}

	//Find the middle point
	float middlePoint[2] = { x1, y1 };
	for (int i = 1; i < 3; i++) {
		if (points[i][1] < lowestPoint[1] && points[i][1] > highestPoint[1]) {
			middlePoint[0] = points[i][0];
			middlePoint[1] = points[i][1];
			break;
		}
	}

	//Find the intersection
	float intersection[2];
	if (highestPoint[0] - lowestPoint[0] != 0) {
		float slope = (highestPoint[1] - lowestPoint[1]) / (highestPoint[0] - lowestPoint[0]);
		float intercept = lowestPoint[1] - lowestPoint[0] * slope;

		intersection[0] = (middlePoint[1] - intercept) / slope;
		intersection[1] = middlePoint[1];
	}
	else {
		intersection[0] = highestPoint[0];
		intersection[1] = middlePoint[1];
	}

	//Fill the triangles
	//Check to make sure that the triangle isn't flat based
	if (y1 != y2 && y2 != y3 && y1 != y3) {
		fillFlatTopTriangle(hdc, color, lowestPoint[0], lowestPoint[1],
			middlePoint[0], middlePoint[1], intersection[0], intersection[1]);
		fillFlatBottomTriangle(hdc, color, highestPoint[0], highestPoint[1],
			middlePoint[0], middlePoint[1], intersection[0], intersection[1]);
	}
	else {
		//Handle the trivial case of a flat based triangle
		if (y1 == y2) {
			if (y1 == lowestPoint[1]) {
				fillFlatBottomTriangle(hdc, color, x3, y3, x1, y1, x2, y2);
			}
			else {
				fillFlatTopTriangle(hdc, color, x3, y3, x1, y1, x2, y2);
			}
		}
		else if (y2 == y3) {
			if (y2 == lowestPoint[1]) {
				fillFlatBottomTriangle(hdc, color, x1, y1, x2, y2, x3, y3);
			}
			else {
				fillFlatTopTriangle(hdc, color, x1, y1, x2, y2, x3, y3);
			}
		}
		else if (y1 == y3) {
			if (y3 == lowestPoint[1]) {
				fillFlatBottomTriangle(hdc, color, x2, y2, x1, y1, x3, y3);
			}
			else {
				fillFlatTopTriangle(hdc, color, x2, y2, x1, y1, x3, y3);
			}
		}
	}
}