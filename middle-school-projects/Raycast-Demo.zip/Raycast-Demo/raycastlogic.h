#include <vector>
#include "drawlogic.h"
#include <math.h>
#include <sstream>
#include <windows.h>
#pragma once

//pi constant
const float pi = 3.141592653;

/*
	This structure will store the return value of the projectRay function
*/
struct RayCastData {
	//The distance
	float dist = 0.0f;
	//The side that was hit
	int side = 0;
	//The type of block
	int type = 0;

	COLORREF color() {
		int red = 0, green = 0, blue = 0;

		switch (type) {
		case 1:
			//Gray wall
			red = 140; green = 140; blue = 140;
			break;
		case 2:
			//Magenta wall
			red = 255; green = 0; blue = 255;
			break;
		case 3:
			//Red wall
			red = 255; green = 0; blue = 0;
			break;
		case 4:
			//Blue wall
			red = 0; green = 0; blue = 255;
		}

		//Shade the side
		if (side == 2) {
			red *= 0.7; green *= 0.7; blue *= 0.7;
		}

		return RGB(red, green, blue);
	}
};

//2D vector structure
struct Vector2D {
	//X and Y
	float x = 0.0f, y = 0.0f;

	//Magnitude of the vector
	float mag() {
		return sqrt(x * x + y * y);
	}

	//Return a normal vector
	Vector2D getNormal() {
		return { this->y / mag(), -(this->x) / mag() };
	}

	//Subtraction operator
	Vector2D operator - (Vector2D v) {
		Vector2D result;
		result.x = this->x - v.x;
		result.y = this->y - v.y;
		return result;
	}

	//Dot product
	float operator * (Vector2D v) {
		return this->x*v.x + this->y*v.y;
	}
};


//Convert degrees into radians
float degreesToRadians(float degrees) {
	return degrees * pi / 180;
}

/*
	This function will convert a degree value that is greater than 360 into the corresponding value that is "equivelant"
	If the degree value is less than 0, then it will be converted to the positive value that is the "equivelant"
	The function will only return a value between 0 and 360
*/
float convertDeg(float &degrees) {
	//Handle negative angles
	if (degrees < 0) {
		while (degrees < 0) {
			degrees += 360;
		}
	}
	//Handle angles greater than 360
	else if (degrees >= 360) {
		while (degrees >= 360) {
			degrees -= 360;
		}
	}
	return degrees;
}

/*
	This function will project a ray outward until it hits a block
	Once it hits a block, it will return the distance that it traveled

	Parameters:
	1. Map - A vector of integers ( 0 = nothing, 1 = wall )
	2. The vector that will represent the location of the player/camera
	3. The angle that the ray will travel along
	4. The maximum distance the ray will travel before stopping - If the ray hits the max distance, it will return -1
	5. The rotation of the camera
*/
RayCastData projectRay(std::vector<std::vector<int>> map, Vector2D cameraLocation, float degree, float maxDist, float rotation) {
	//Store the distance
	float dist = -1.0f;
	//Slope of the line
	float slope = tan(degreesToRadians(degree));
	float offset = cameraLocation.y - cameraLocation.x * slope;
	//Starting location for the line
	float startX;
	float startY;
	//Store the coordiantes of the 'hit' point
	Vector2D hit;
	//Ray cast data
	RayCastData raydata;

	//Set the starting x location
	if (cos(degreesToRadians(degree)) < 0) {
		startX = floor(cameraLocation.x);
	}
	else {
		startX = ceil(cameraLocation.x);
	}
	//Set the starting y location
	if (sin(degreesToRadians(degree)) < 0) {
		startY = floor(cameraLocation.y);
	}
	else {
		startY = ceil(cameraLocation.y);
	}

	//Vertical Line check
	if (cos(degreesToRadians(degree)) > 0) {
		for (int i = 0; i <= maxDist; i++) {
			float XCOR = startX + i;
			float YCOR = XCOR * slope + offset;

			try {
				if (map.at(floor(YCOR)).at(floor(XCOR) - 1) > 0 || map.at(floor(YCOR)).at(floor(XCOR)) > 0) {
					dist = sqrt((cameraLocation.x - XCOR)*(cameraLocation.x - XCOR) +
						(cameraLocation.y - YCOR)*(cameraLocation.y - YCOR));

					hit.x = XCOR;
					hit.y = YCOR;

					raydata.side = 1;

					if (map.at(floor(YCOR)).at(floor(XCOR) - 1) > 0) {
						raydata.type = map.at(floor(YCOR)).at(floor(XCOR) - 1);
					}
					else {
						raydata.type = map.at(floor(YCOR)).at(floor(XCOR));
					}

					break;
				}
			}
			catch (std::out_of_range) { break; }
		}
	}
	else if (cos(degreesToRadians(degree)) < 0) {
		for (int i = 0; i <= maxDist; i++) {
			float XCOR = startX - i;
			float YCOR = XCOR * slope + offset;

			try {
				if (map.at(floor(YCOR)).at(floor(XCOR) - 1) > 0 || map.at(floor(YCOR)).at(floor(XCOR)) > 0) {
					dist = sqrt((cameraLocation.x - XCOR)*(cameraLocation.x - XCOR) +
						(cameraLocation.y - YCOR)*(cameraLocation.y - YCOR));

					hit.x = XCOR;
					hit.y = YCOR;

					raydata.side = 1;

					if (map.at(floor(YCOR)).at(floor(XCOR) - 1) > 0) {
						raydata.type = map.at(floor(YCOR)).at(floor(XCOR) - 1);
					}
					else {
						raydata.type = map.at(floor(YCOR)).at(floor(XCOR));
					}

					break;
				}
			}
			catch (std::out_of_range) { break; }
		}
	}

	//Horizontal line check
	if (sin(degreesToRadians(degree)) > 0) {
		for (int i = 0; i <= maxDist; i++) {
			float YCOR = startY + i;
			float XCOR = (YCOR - offset) / slope;

			try {
				if (map.at(floor(YCOR) - 1).at(floor(XCOR)) > 0 || map.at(floor(YCOR)).at(floor(XCOR)) > 0) {
					float tempdist = sqrt((cameraLocation.x - XCOR)*(cameraLocation.x - XCOR) +
						(cameraLocation.y - YCOR)*(cameraLocation.y - YCOR));

					if (tempdist < dist || dist == -1.0f) {
						dist = tempdist;

						hit.x = XCOR;
						hit.y = YCOR;

						raydata.side = 2;

						if (map.at(floor(YCOR) - 1).at(floor(XCOR)) > 0) {
							raydata.type = map.at(floor(YCOR) - 1).at(floor(XCOR));
						}
						else {
							raydata.type = map.at(floor(YCOR)).at(floor(XCOR));
						}
					}
					break;
				}
			}
			catch (std::out_of_range) { break; }
		}
	}
	else if (sin(degreesToRadians(degree)) < 0) {
		for (int i = 0; i <= maxDist; i++) {
			float YCOR = startY - i;
			float XCOR = (YCOR - offset) / slope;

			try {
				if (map.at(floor(YCOR) - 1).at(floor(XCOR)) > 0 || map.at(floor(YCOR)).at(floor(XCOR)) > 0) {
					float tempdist = sqrt((cameraLocation.x - XCOR)*(cameraLocation.x - XCOR) +
						(cameraLocation.y - YCOR)*(cameraLocation.y - YCOR));

					if (tempdist < dist || dist == -1.0f) {
						dist = tempdist;

						hit.x = XCOR;
						hit.y = YCOR;

						raydata.side = 2;

						if (map.at(floor(YCOR) - 1).at(floor(XCOR)) > 0) {
							raydata.type = map.at(floor(YCOR) - 1).at(floor(XCOR));
						}
						else {
							raydata.type = map.at(floor(YCOR)).at(floor(XCOR));
						}
					}
					break;
				}
			}
			catch (std::out_of_range) { break; }
		}
	}

	//Calculate the distance to the camera plane
	if (rotation == 90.0f || rotation == 270.0f) {
		dist = abs(hit.y - cameraLocation.y);
	}
	else if (tan(rotation) != 0.0) {
		float slope2 = -1.0f / tan(degreesToRadians(rotation));
		float offset2 = cameraLocation.y - slope2 * cameraLocation.x;

		float slope3 = tan(degreesToRadians(rotation));
		float offset3 = hit.y - hit.x * slope3;

		Vector2D intersection;
		intersection.x = (offset3 - offset2) / (slope2 - slope3);
		intersection.y = slope3 * intersection.x + offset3;

		dist = (hit - intersection).mag();
	}
	else {
		dist = abs(hit.x - cameraLocation.x);
	}

	//Set the distance value for the ray cast data
	raydata.dist = dist;

	return raydata;
}

//Draws the ray that is cast at an angle (used for debugging)
void drawRayHit(HDC hdc, std::vector<std::vector<int>> map, Vector2D cameraLocation, float degree, float maxDist, float rotation) {	
	//Store the distance
	float dist = -1.0f;
	//Slope of the ray
	float slope = tan(degreesToRadians(degree));
	//Offset of the ray
	float offset = cameraLocation.y - cameraLocation.x * slope;
	//Starting coordinates of the ray
	float startX;
	float startY;
	//Set up the starting location of the ray
	if (cos(degreesToRadians(degree)) < 0) {
		startX = floor(cameraLocation.x);
	}
	else {
		startX = ceil(cameraLocation.x);
	}

	if (sin(degreesToRadians(degree)) < 0) {
		startY = floor(cameraLocation.y);
	}
	else {
		startY = ceil(cameraLocation.y);
	}
	//Store where the ray hit
	Vector2D hit;

	//Vertical Line check
	if (cos(degreesToRadians(degree)) > 0) {
		for (int i = 0; i <= maxDist; i++) {
			float XCOR = startX + i;
			float YCOR = XCOR * slope + offset;

			try {
				if (map.at(floor(YCOR)).at(floor(XCOR) - 1) > 0 || map.at(floor(YCOR)).at(floor(XCOR)) > 0) {
					dist = sqrt((cameraLocation.x - XCOR)*(cameraLocation.x - XCOR) +
						(cameraLocation.y - YCOR)*(cameraLocation.y - YCOR));

					hit.x = XCOR;
					hit.y = YCOR;
					break;
				}
			}
			catch (std::out_of_range) { break; }
		}
	}
	else if (cos(degreesToRadians(degree)) < 0) {
		for (int i = 0; i <= maxDist; i++) {
			float XCOR = startX - i;
			float YCOR = XCOR * slope + offset;

			try {
				if (map.at(floor(YCOR)).at(floor(XCOR) - 1) > 0 || map.at(floor(YCOR)).at(floor(XCOR)) > 0) {
					dist = sqrt((cameraLocation.x - XCOR)*(cameraLocation.x - XCOR) +
						(cameraLocation.y - YCOR)*(cameraLocation.y - YCOR));

					hit.x = XCOR;
					hit.y = YCOR;
					break;
				}
			}
			catch (std::out_of_range) { break; }
		}
	}

	//Horizontal line check
	if (sin(degreesToRadians(degree)) > 0) {
		for (int i = 0; i <= maxDist; i++) {
			float YCOR = startY + i;
			float XCOR = (YCOR - offset) / slope;

			try {
				if (map.at(floor(YCOR) - 1).at(floor(XCOR)) > 0 || map.at(floor(YCOR)).at(floor(XCOR)) > 0) {
					float tempdist = sqrt((cameraLocation.x - XCOR)*(cameraLocation.x - XCOR) +
						(cameraLocation.y - YCOR)*(cameraLocation.y - YCOR));

					if (tempdist < dist || dist == -1.0f) {
						hit.x = XCOR;
						hit.y = YCOR;

						dist = tempdist;
					}
					break;
				}
			}
			catch (std::out_of_range) { break; }
		}
	}
	else if (sin(degreesToRadians(degree)) < 0) {
		for (int i = 0; i <= maxDist; i++) {
			float YCOR = startY - i;
			float XCOR = (YCOR - offset) / slope;

			try {
				if (map.at(floor(YCOR) - 1).at(floor(XCOR)) > 0 || map.at(floor(YCOR)).at(floor(XCOR)) > 0) {
					float tempdist = sqrt((cameraLocation.x - XCOR)*(cameraLocation.x - XCOR) +
						(cameraLocation.y - YCOR)*(cameraLocation.y - YCOR));

					if (tempdist < dist || dist == -1.0f) {
						hit.x = XCOR;
						hit.y = YCOR;

						dist = tempdist;
					}
					break;
				}
			}
			catch (std::out_of_range) { break; }
		}
	}
	//If the distance is -1, then that means that the ray didn't hit any blocks
	if (dist == -1.0f) {
		return;
	}
	//Draw the ray
	drawLine(hdc, RGB(0, 128, 255), cameraLocation.x * 20, cameraLocation.y * 20, hit.x * 20, hit.y * 20);
}